"""Real, tiny federated-learning client for the GAUD-E prototype.

This is intentionally small and educational. Data is generated/held locally and
only model parameters + metrics are sent to the coordinator.
"""
from __future__ import annotations
import argparse, base64, io, json, time
from dataclasses import dataclass
from typing import Dict
import requests
import torch
from torch import nn
from protocol.hashing import sha256_json
from protocol.crypto import generate_keypair, sign

class TinyClassifier(nn.Module):
    def __init__(self, features: int = 2):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(features, 8), nn.Tanh(), nn.Linear(8, 2))
    def forward(self, x):
        return self.net(x)

def make_data(n: int, seed: int):
    g = torch.Generator().manual_seed(seed)
    x = torch.randn(n, 2, generator=g)
    y = (x[:, 0] + 0.8 * x[:, 1] > 0).long()
    return x, y

def train_local(model: nn.Module, x, y, epochs: int = 2):
    opt = torch.optim.SGD(model.parameters(), lr=0.08)
    loss_fn = nn.CrossEntropyLoss()
    model.train()
    for _ in range(epochs):
        opt.zero_grad(); loss = loss_fn(model(x), y); loss.backward(); opt.step()

def accuracy(model, x, y):
    model.eval()
    with torch.no_grad():
        return float((model(x).argmax(1) == y).float().mean().item())

def encode_state(state: Dict[str, torch.Tensor]) -> str:
    buffer = io.BytesIO()
    torch.save({k: v.detach().cpu() for k, v in state.items()}, buffer)
    return base64.b64encode(buffer.getvalue()).decode()

def decode_state(payload: str):
    raw = base64.b64decode(payload)
    return torch.load(io.BytesIO(raw), map_location="cpu", weights_only=True)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--coordinator', default='http://127.0.0.1:8080')
    p.add_argument('--client-id', default='client-01')
    p.add_argument('--samples', type=int, default=160)
    p.add_argument('--epochs', type=int, default=2)
    p.add_argument('--seed', type=int, default=7)
    args = p.parse_args()

    keys = generate_keypair()
    model = TinyClassifier()
    local_x, local_y = make_data(args.samples, args.seed)
    session = requests.Session()

    session.post(f'{args.coordinator}/federated/register', json={'client_id': args.client_id, 'public_key': keys.public_key}, timeout=10).raise_for_status()
    round_info = session.get(f'{args.coordinator}/federated/round/current', timeout=10).json()
    if round_info.get('status') == 'empty':
        print('No active federated round.')
        return
    global_state = decode_state(round_info['global_state'])
    model.load_state_dict(global_state)
    before = accuracy(model, local_x, local_y)
    train_local(model, local_x, local_y, args.epochs)
    after = accuracy(model, local_x, local_y)

    body = {
        'round_id': round_info['round_id'],
        'client_id': args.client_id,
        'model_hash': round_info['model_hash'],
        'samples': args.samples,
        'metrics': {'accuracy_before': before, 'accuracy_after': after},
        'state': encode_state(model.state_dict()),
        'submitted_at': time.time(),
    }
    body['update_hash'] = sha256_json({k: body[k] for k in body if k != 'state'})
    body_bytes = json.dumps(body, sort_keys=True, separators=(',', ':')).encode()
    body['signature'] = sign(keys.private_key, body_bytes)
    body['public_key'] = keys.public_key

    r = session.post(f'{args.coordinator}/federated/update', json=body, timeout=30)
    r.raise_for_status()
    print(json.dumps({'client_id': args.client_id, 'before': before, 'after': after, 'server': r.json()}, indent=2))

if __name__ == '__main__':
    main()
