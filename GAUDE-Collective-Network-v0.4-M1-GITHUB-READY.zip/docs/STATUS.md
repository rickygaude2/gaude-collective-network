# Status — v0.4

GAUD-E is now beyond the synthetic M0 protocol loop.

Implemented in this release:

- real local PyTorch training;
- weighted federated averaging;
- signed client updates (Ed25519);
- model/update hashing;
- validator HTTP skeleton;
- EVM contribution registry;
- blockchain gateway using ethers.js;
- reward vault retained as experimental settlement component.

Not production ready:

- no secure aggregation yet;
- no Byzantine-robust aggregation yet;
- no production P2P transport yet;
- no audited contracts;
- no mainnet token launch;
- no claim of privacy merely because raw samples are not uploaded.
