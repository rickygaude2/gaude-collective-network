# M1: Real Federated Learning Prototype

GAUD-E v0.4 introduces a real, small-scale federated-learning loop using PyTorch.

## What it does

1. The coordinator creates a global model.
2. Clients download the current model.
3. Each client trains locally on data it generates/holds locally.
4. Clients send model parameters and metrics, not the original samples.
5. The coordinator performs weighted FedAvg.
6. The next global model is created from multiple contributions.

## What it does NOT claim yet

This is not production-grade privacy or Byzantine-resilient federated learning.
The prototype still needs secure aggregation, client attestation, differential privacy,
robust aggregation, malicious-update detection, persistence and P2P transport.

The purpose is to prove the collective-learning loop first.
