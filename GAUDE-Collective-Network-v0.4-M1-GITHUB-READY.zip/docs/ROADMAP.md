# Roadmap

## v0.4 — Federated Learning + Blockchain Gateway
- [x] real PyTorch local training demo
- [x] weighted FedAvg coordinator
- [x] signed client updates
- [x] update/model hashes
- [x] validator service skeleton
- [x] EVM contribution gateway
- [x] contribution registry contract

## v0.5 — P2P Alpha
- [ ] libp2p node identity
- [ ] peer discovery
- [ ] signed job gossip
- [ ] direct worker-to-worker transport

## v0.6 — Trust
- [ ] robust aggregation
- [ ] stake + slashing design
- [ ] challenge/dispute protocol
- [ ] secure aggregation

## v1.0 — Collective AI Alpha
- [ ] real open-weight language model
- [ ] distributed RL / fine-tuning
- [ ] reproducible global model registry
- [ ] public testnet
- [ ] energy accounting
