"""Small Ed25519 identity helpers for the GAUD-E prototype."""
from __future__ import annotations
import base64
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

@dataclass(frozen=True)
class KeyPair:
    private_key: str
    public_key: str

def generate_keypair() -> KeyPair:
    private = Ed25519PrivateKey.generate()
    public = private.public_key()
    priv = base64.b64encode(private.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())).decode()
    pub = base64.b64encode(public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)).decode()
    return KeyPair(priv, pub)

def sign(private_b64: str, message: bytes) -> str:
    private = Ed25519PrivateKey.from_private_bytes(base64.b64decode(private_b64))
    return base64.b64encode(private.sign(message)).decode()

def verify(public_b64: str, message: bytes, signature_b64: str) -> bool:
    try:
        public = Ed25519PublicKey.from_public_bytes(base64.b64decode(public_b64))
        public.verify(base64.b64decode(signature_b64), message)
        return True
    except Exception:
        return False
