# GAUD-E Collective Network

> **One global AI. Built, improved and powered by everyone.**

Open-source research protocol for a collectively built and collectively operated AI network.

**Start here:** [Project definition](docs/PROJECT.md) · [Architecture](docs/ARCHITECTURE.md) · [Roadmap](docs/ROADMAP.md) · [Getting started](docs/GETTING_STARTED.md) · [Whitepaper](docs/WHITEPAPER.md) · [Token research](docs/TOKENOMICS.md) · [How to contribute](CONTRIBUTING.md)

GAUD-E Collective Network (GCN) is an open-source research protocol for building a **collective AI**: a shared model or model family that is trained, evaluated and served by a distributed community of computers, GPUs, validators, researchers and users.

The key idea is simple:

**Participants do not own separate private AIs. The network collectively builds and operates one global intelligence.**

The protocol separates concerns:

- **AI layer:** training, inference and evaluation happen off-chain.
- **P2P compute layer:** participants contribute GPU/CPU/edge capacity.
- **Verification layer:** the network checks whether work was actually performed and whether it improved the system.
- **Blockchain layer:** identities, commitments, reputation, settlement and governance are recorded on-chain.
- **Economic layer:** useful, verified contribution is rewarded; the protocol should eventually be funded by real demand for AI services rather than perpetual token inflation.

## Why this project exists

Today, frontier AI is concentrated because training and inference require enormous compute, data and capital. GAUD-E explores a different model: turn many independent machines into a coordinated AI infrastructure and make the resulting network economically participatory.

This repository is **not** a finished decentralized AI and it is **not financial advice**. The token contracts are prototype/testnet components only. Mainnet deployment, token sales and any profit-sharing mechanism require technical, security and legal review.

## MVP goal

The first milestone is intentionally small:

```text
worker registers
      ↓
receives AI job
      ↓
performs useful local computation
      ↓
signs / hashes a contribution receipt
      ↓
validator checks result
      ↓
reward is simulated
```

Then we progressively replace the coordinator with P2P discovery, replace the synthetic job with real ML workloads, and add on-chain settlement.

## Architecture

```text
             USERS / APPS / AGENTS
                       │
                       ▼
              COLLECTIVE AI API
                       │
                       ▼
                JOB ORCHESTRATOR
                       │
         ┌─────────────┼─────────────┐
         ▼             ▼             ▼
      TRAINING      INFERENCE     EVALUATION
       WORKERS       WORKERS       VALIDATORS
         │             │             │
         └─────────────┼─────────────┘
                       ▼
                 PROOF ENGINE
          replay / sampling / TEE / ZK
                       │
                       ▼
                  BLOCKCHAIN
      commitments / rewards / reputation
                       │
                       ▼
               COLLECTIVE ECONOMY
```

**Important:** the blockchain does not perform tensor operations. Large model weights and datasets remain off-chain; the chain stores compact commitments, proofs and settlement data.


## Project website

The public landing page and contributor portal live in [`website/`](website/). You can run it locally with:

```bash
python -m http.server 4173 --directory website
```

GitHub Pages deployment is configured through [`.github/workflows/deploy-pages.yml`](.github/workflows/deploy-pages.yml).

## Community contribution goal

We are building in public. Our first community milestone is **10 active contributors, 10+ test nodes and a reproducible collective-learning benchmark**. Start with [Good First Issues](../../issues?q=is%3Aissue%20label%3A%22good%20first%20issue%22) and [`CONTRIBUTING.md`](CONTRIBUTING.md).

## Repository layout

```text
.
├── contracts/                 # Solidity prototype contracts
├── coordinator/               # Local M0 coordinator API
├── node/                      # Worker node + collective-learning demo
├── protocol/                  # Shared protocol primitives (Python)
├── docs/                      # Project, architecture, roadmap, token design
├── scripts/                   # Local dev helpers
├── tests/                     # Python tests
└── .github/                   # CI + issue templates
```

## Run the local MVP

### Requirements

- Python 3.11+
- pip
- Git
- Optional: NVIDIA GPU for future ML workers
- Optional: Foundry for Solidity development

### 1. Create a virtual environment

```bash
python -m venv .venv
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

### 2. Install Python dependencies

```bash
pip install -r coordinator/requirements.txt
```

### 3. Start the coordinator

```bash
uvicorn coordinator.app:app --reload --port 8080
```

### 4. In another terminal, start a worker

```bash
python node/worker.py --coordinator http://127.0.0.1:8080 --name worker-01
```

A second terminal can run another worker with a different name.

### 5. Run tests

```bash
python -m pytest -q
```

## Collective learning demo

`node/collective_learning.py` demonstrates the **concept** of decentralized aggregation using a tiny synthetic binary-classification task. It is intentionally small so contributors can understand the protocol without needing a GPU or external dataset.

```bash
python node/collective_learning.py --rounds 5 --clients 8
```

The demo is not secure federated learning yet. It is a research scaffold for implementing the real aggregation, privacy, participant sampling and verification layers.

## Proposed contribution model

GAUD-E calls the protocol concept **Proof-of-AI-Contribution (PoAIC)**.

A contribution score should consider:

```text
verified work
× quality
× task difficulty
× reliability
× network demand
```

Different roles can contribute:

- GPU/CPU compute
- inference
- training / reinforcement learning
- evaluation and benchmarking
- validation
- storage and bandwidth
- licensed datasets
- human feedback / preference data
- software and research

The goal is **not** to reward whoever owns the most GPUs. The goal is to reward useful verified work.

See [docs/GITHUB_PROJECT_DESCRIPTION.md](docs/GITHUB_PROJECT_DESCRIPTION.md) for a contributor-facing project description you can reuse on GitHub, project directories and community posts.

## Token philosophy

The repository contains a prototype ERC-20 token named **GAUDE**.

The intended roles are:

- protocol payments
- service fees
- contribution rewards
- staking / security mechanisms
- governance
- ecosystem grants

The initial supply cap in the prototype is 10 billion tokens. **This is a technical placeholder, not a final investment offering or promise of value.**

Mainnet economics should only be finalized after:

1. a working network,
2. measurable real demand,
3. security audits,
4. legal analysis in relevant jurisdictions,
5. a community review of tokenomics.

## First 90-day target

```text
10 contributors
10+ worker nodes
1 reproducible collective-learning benchmark
1 public testnet prototype
1 validator implementation
1 public dashboard
100+ GitHub stars
```

## How to contribute

Start with issues tagged:

- `good first issue`
- `ai-worker`
- `federated-learning`
- `p2p`
- `verification`
- `smart-contracts`
- `security`
- `docs`

Read [CONTRIBUTING.md](CONTRIBUTING.md) first.

## Project status

**Phase 0 — public research + runnable local MVP.**

Nothing in this repository should be interpreted as a claim that the network already provides decentralized training, censorship resistance, privacy guarantees, carbon savings, or financial returns. Those are research and engineering goals to be demonstrated.

## License

Apache-2.0. See [LICENSE](LICENSE).

## v0.4 — real federated learning prototype

The repository now includes a small PyTorch federated-learning loop. Clients train locally and submit model updates plus metrics; the coordinator aggregates them with weighted FedAvg. Client updates are signed with Ed25519 and hashed for traceability. An EVM gateway and contribution registry contract are included for the next settlement step.

### Run the federated prototype

Install dependencies:

```bash
pip install -r requirements-dev.txt
```

Start the API:

```bash
uvicorn coordinator.app:app --reload --port 8080
```

In another terminal, create a round:

```bash
curl -X POST http://127.0.0.1:8080/federated/round/start -H "Content-Type: application/json" -d '{"min_clients":1}'
```

Then run one or more clients:

```bash
python node/federated_client.py --client-id client-01 --seed 7
python node/federated_client.py --client-id client-02 --seed 8
```

Aggregate the round:

```bash
curl -X POST http://127.0.0.1:8080/federated/round/aggregate
```

The result contains a new global model hash. The next iteration will move the same loop to P2P transport and replace the toy model with a real open-weight AI workload.
