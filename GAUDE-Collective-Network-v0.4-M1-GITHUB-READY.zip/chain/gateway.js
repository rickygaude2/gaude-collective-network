import 'dotenv/config';
import { ethers } from 'ethers';
import http from 'node:http';

const PORT = Number(process.env.PORT || 8090);
const RPC_URL = process.env.RPC_URL || 'http://127.0.0.1:8545';
const PRIVATE_KEY = process.env.PROTOCOL_PRIVATE_KEY;
const REGISTRY = process.env.CONTRIBUTION_REGISTRY;
const REGISTRY_ABI = [
  'function record((address worker,bytes32 jobId,bytes32 modelHash,bytes32 datasetHash,bytes32 receiptHash,uint64 timestamp,uint32 qualityBps,uint256 rewardAmount)) returns (bytes32)',
  'event ContributionRecorded(bytes32 indexed contributionId,bytes32 indexed jobId,address indexed worker,uint32 qualityBps,uint256 rewardAmount)'
];

const provider = new ethers.JsonRpcProvider(RPC_URL);
const wallet = PRIVATE_KEY ? new ethers.Wallet(PRIVATE_KEY, provider) : null;
const registry = wallet && REGISTRY ? new ethers.Contract(REGISTRY, REGISTRY_ABI, wallet) : null;

async function recordContribution(body) {
  if (!registry) throw new Error('Gateway not configured: set PROTOCOL_PRIVATE_KEY and CONTRIBUTION_REGISTRY');
  const tx = await registry.record({
    worker: body.worker,
    jobId: ethers.id(body.job_id),
    modelHash: ethers.id(body.model_hash),
    datasetHash: ethers.id(body.dataset_hash),
    receiptHash: ethers.id(body.receipt_hash),
    timestamp: BigInt(Math.floor(body.timestamp || Date.now()/1000)),
    qualityBps: Number(body.quality_bps || 0),
    rewardAmount: BigInt(body.reward_amount || 0)
  });
  const receipt = await tx.wait();
  return {txHash: receipt.hash, blockNumber: receipt.blockNumber};
}

const server = http.createServer(async (req,res)=>{
  res.setHeader('content-type','application/json');
  try {
    if (req.method === 'GET' && req.url === '/health') return res.end(JSON.stringify({ok:true, chainId:(await provider.getNetwork()).chainId.toString(), configured:Boolean(registry)}));
    if (req.method === 'POST' && req.url === '/contributions/record') {
      let raw=''; req.on('data',c=>raw+=c); req.on('end', async()=>{
        try { const out = await recordContribution(JSON.parse(raw)); res.statusCode=200; res.end(JSON.stringify(out)); }
        catch(e){ res.statusCode=400; res.end(JSON.stringify({error:e.message})); }
      }); return;
    }
    res.statusCode=404; res.end(JSON.stringify({error:'not found'}));
  } catch(e) { res.statusCode=500; res.end(JSON.stringify({error:e.message})); }
});
server.listen(PORT, ()=>console.log(`GAUD-E chain gateway listening on ${PORT}`));
