# GAUD-E EVM Gateway

This service submits verified contribution commitments to the GAUD-E ContributionRegistry contract.

## Development

```bash
npm install
cp .env.example .env
npm run dev
```

Do not place real private keys in Git. The `.gitignore` excludes `.env`.

The gateway intentionally refuses to operate until both a protocol private key and registry address are configured.
