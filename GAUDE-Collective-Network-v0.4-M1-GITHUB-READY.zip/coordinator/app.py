from __future__ import annotations
import hashlib, time, uuid
from typing import Any
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from coordinator.federated import FederatedCoordinator

app = FastAPI(title='GAUD-E Collective Coordinator', version='0.4.0')
workers: dict[str, dict[str, Any]] = {}
completions: dict[str, dict[str, Any]] = {}
job = {"job_id": f"job-{uuid.uuid4().hex[:12]}", "model_hash": hashlib.sha256(b"gaude-collective-model-m0").hexdigest(), "dataset_hash": hashlib.sha256(b"gaude-collective-dataset-m0").hexdigest(), "reward_units": 100}
federated = FederatedCoordinator()

class WorkerRegistration(BaseModel):
    name: str = Field(min_length=1, max_length=100); hostname: str = Field(min_length=1, max_length=200); platform: str = Field(min_length=1, max_length=300); cpu_count: int = Field(ge=1, le=4096); memory_gb: float = Field(gt=0, le=100000)

class ClientRegistration(BaseModel):
    client_id: str = Field(min_length=1, max_length=120); public_key: str = Field(min_length=20)

@app.get('/')
def root(): return {'project':'GAUD-E Collective Network','status':'m1-federated-prototype','workers':len(workers),'federated_clients':len(federated.clients)}

@app.post('/workers/register')
def register_worker(payload: WorkerRegistration):
    workers[payload.name] = {**payload.model_dump(), 'registered_at': time.time()}; return {'status':'registered','worker':payload.name}

@app.get('/workers')
def list_workers(): return {'workers':list(workers.values())}

@app.get('/jobs/next')
def next_job():
    if completions.get(job['job_id']): return {'status':'empty'}
    return job

@app.post('/jobs/{job_id}/complete')
def complete_job(job_id: str, receipt: dict[str, Any]):
    if job_id != job['job_id']: raise HTTPException(404, 'unknown job')
    if not receipt.get('receipt_hash'): raise HTTPException(400, 'missing receipt_hash')
    completions[job_id] = receipt
    return {'status':'accepted-for-verification','job_id':job_id,'receipt_hash':receipt['receipt_hash'],'simulated_reward_units':job['reward_units']}

@app.get('/federated/clients')
def federated_clients(): return {'clients':federated.clients}

@app.post('/federated/register')
def federated_register(payload: ClientRegistration):
    federated.register(payload.client_id, payload.public_key); return {'status':'registered','client_id':payload.client_id}

@app.post('/federated/round/start')
def federated_start(body: dict[str, Any] | None = None):
    return federated.start_round(min_clients=int((body or {}).get('min_clients',1)))

@app.get('/federated/round/current')
def federated_current():
    return federated.round or {'status':'empty'}

@app.post('/federated/update')
def federated_update(body: dict[str, Any]):
    try: return federated.submit(body)
    except ValueError as exc: raise HTTPException(400, str(exc)) from exc

@app.post('/federated/round/aggregate')
def federated_aggregate():
    try: return federated.aggregate()
    except ValueError as exc: raise HTTPException(400, str(exc)) from exc

@app.get('/federated/history')
def federated_history(): return {'rounds':federated.history}
