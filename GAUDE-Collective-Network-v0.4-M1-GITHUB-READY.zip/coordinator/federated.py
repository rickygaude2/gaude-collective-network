from __future__ import annotations
import base64, io, time, uuid
from typing import Any
import torch
from node.federated_client import TinyClassifier
from protocol.crypto import verify
from protocol.hashing import sha256_json

class FederatedCoordinator:
    def __init__(self):
        self.clients: dict[str, dict[str, str]] = {}
        self.round: dict[str, Any] | None = None
        self.history: list[dict[str, Any]] = []

    def register(self, client_id: str, public_key: str):
        self.clients[client_id] = {'public_key': public_key, 'registered_at': time.time()}

    def start_round(self, min_clients: int = 1):
        model = TinyClassifier()
        buf = io.BytesIO(); torch.save(model.state_dict(), buf)
        global_state = base64.b64encode(buf.getvalue()).decode()
        state_hash = sha256_json({'state': global_state})
        self.round = {
            'round_id': f'round-{uuid.uuid4().hex[:12]}',
            'model_hash': state_hash,
            'global_state': global_state,
            'updates': [],
            'started_at': time.time(),
            'min_clients': min_clients,
        }
        return self.round

    def submit(self, payload: dict[str, Any]):
        if not self.round or payload.get('round_id') != self.round['round_id']:
            raise ValueError('no matching round')
        client = self.clients.get(payload.get('client_id'))
        if not client:
            raise ValueError('unknown client')
        if payload.get('model_hash') != self.round['model_hash']:
            raise ValueError('model hash mismatch')
        if not verify(client['public_key'], _canonical_update_bytes(payload), payload.get('signature','')):
            raise ValueError('invalid signature')
        expected = sha256_json({k: payload[k] for k in payload if k not in {'state','signature','public_key','update_hash'}})
        if expected != payload.get('update_hash'):
            raise ValueError('update hash mismatch')
        self.round['updates'].append(payload)
        return {'accepted': True, 'updates': len(self.round['updates'])}

    def aggregate(self):
        if not self.round or not self.round['updates']:
            raise ValueError('no updates')
        tensors = []
        weights = []
        for u in self.round['updates']:
            raw = base64.b64decode(u['state'])
            state = torch.load(io.BytesIO(raw), map_location='cpu', weights_only=True)
            tensors.append(state); weights.append(max(int(u['samples']), 1))
        total = sum(weights)
        agg = {}
        for key in tensors[0].keys():
            agg[key] = sum(state[key] * (w / total) for state, w in zip(tensors, weights))
        buf = io.BytesIO(); torch.save(agg, buf)
        encoded = base64.b64encode(buf.getvalue()).decode()
        old = self.round
        new_hash = sha256_json({'state': encoded})
        result = {
            'round_id': old['round_id'],
            'clients': len(old['updates']),
            'samples': total,
            'previous_model_hash': old['model_hash'],
            'new_model_hash': new_hash,
            'completed_at': time.time(),
        }
        self.history.append(result)
        self.round = None
        return {**result, 'global_state': encoded}

def _canonical_update_bytes(payload: dict[str, Any]) -> bytes:
    import json
    clean = {k: payload[k] for k in payload if k not in {'signature','public_key'}}
    return json.dumps(clean, sort_keys=True, separators=(',', ':')).encode()
