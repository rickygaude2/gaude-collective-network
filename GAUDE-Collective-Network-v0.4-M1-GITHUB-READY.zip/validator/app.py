from __future__ import annotations
from typing import Any
from fastapi import FastAPI, HTTPException
from protocol.crypto import verify
from protocol.hashing import sha256_json
import json

app = FastAPI(title='GAUD-E Validator', version='0.4.0')

@app.get('/')
def root():
    return {'service':'gaude-validator','status':'online','version':'0.4.0'}

@app.post('/verify/signature')
def verify_signature(payload: dict[str, Any]):
    required = {'public_key','signature','message'}
    if not required.issubset(payload):
        raise HTTPException(400, 'public_key, signature and message required')
    ok = verify(payload['public_key'], payload['message'].encode(), payload['signature'])
    return {'valid': ok}

@app.post('/verify/commitment')
def verify_commitment(payload: dict[str, Any]):
    required = {'job_id','model_hash','dataset_hash','result_hash'}
    if not required.issubset(payload):
        raise HTTPException(400, 'missing commitment fields')
    digest = sha256_json({k: payload[k] for k in sorted(required)})
    return {'valid': True, 'commitment_hash': digest}
