import io, base64
from node.federated_client import TinyClassifier, make_data, train_local, accuracy, encode_state, decode_state

def test_local_training_improves_or_holds_accuracy():
    m = TinyClassifier(); x,y = make_data(300, 11); before=accuracy(m,x,y); train_local(m,x,y,epochs=4); after=accuracy(m,x,y)
    assert after >= before - 0.05

def test_state_roundtrip():
    m = TinyClassifier(); payload=encode_state(m.state_dict()); state=decode_state(payload); assert set(state.keys()) == set(m.state_dict().keys())
