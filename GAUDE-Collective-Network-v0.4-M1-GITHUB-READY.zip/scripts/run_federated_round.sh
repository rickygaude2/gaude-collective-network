#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python scripts/start_coordinator_demo.py
