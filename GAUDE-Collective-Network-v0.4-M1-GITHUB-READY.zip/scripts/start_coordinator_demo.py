from __future__ import annotations
import threading, time, json, subprocess, sys
import requests
from coordinator.app import app
import uvicorn

def serve():
    uvicorn.run(app, host='127.0.0.1', port=8080, log_level='error')

if __name__ == '__main__':
    t = threading.Thread(target=serve, daemon=True); t.start(); time.sleep(1)
    requests.post('http://127.0.0.1:8080/federated/register', json={'client_id':'demo-1','public_key':'demo'}, timeout=5)
    r = requests.post('http://127.0.0.1:8080/federated/round/start', json={'min_clients':1}, timeout=5); print(r.json())
    print('Run in another terminal: python node/federated_client.py --client-id client-01')
    print('Then finalize with: POST /federated/round/aggregate')
    while True: time.sleep(60)
