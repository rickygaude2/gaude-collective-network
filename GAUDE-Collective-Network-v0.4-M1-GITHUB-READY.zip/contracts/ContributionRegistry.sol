// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

contract ContributionRegistry is AccessControl {
    bytes32 public constant RECORDER_ROLE = keccak256("RECORDER_ROLE");
    struct Contribution {
        address worker;
        bytes32 jobId;
        bytes32 modelHash;
        bytes32 datasetHash;
        bytes32 receiptHash;
        uint64 timestamp;
        uint32 qualityBps;
        uint256 rewardAmount;
    }
    mapping(bytes32 => Contribution) public contributions;
    event ContributionRecorded(bytes32 indexed contributionId, bytes32 indexed jobId, address indexed worker, uint32 qualityBps, uint256 rewardAmount);

    constructor(address admin) {
        require(admin != address(0), "admin=zero");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(RECORDER_ROLE, admin);
    }

    function record(Contribution calldata c) external onlyRole(RECORDER_ROLE) returns (bytes32 id) {
        id = keccak256(abi.encode(c.worker, c.jobId, c.receiptHash));
        require(contributions[id].timestamp == 0, "already-recorded");
        contributions[id] = c;
        emit ContributionRecorded(id, c.jobId, c.worker, c.qualityBps, c.rewardAmount);
    }
}
