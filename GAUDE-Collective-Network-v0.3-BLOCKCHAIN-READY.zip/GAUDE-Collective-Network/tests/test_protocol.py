from protocol.hashing import sha256_json


def test_canonical_hash_is_stable():
    payload_a = {"b": 2, "a": 1}
    payload_b = {"a": 1, "b": 2}
    assert sha256_json(payload_a) == sha256_json(payload_b)


def test_receipt_hash_changes_when_job_changes():
    a = {"job_id": "1", "score": 0.9}
    b = {"job_id": "2", "score": 0.9}
    assert sha256_json(a) != sha256_json(b)
