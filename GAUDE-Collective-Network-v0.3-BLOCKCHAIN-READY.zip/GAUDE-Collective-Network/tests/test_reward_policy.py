from protocol.reward_policy import RewardInput, compute_reward_units


def test_reward_is_positive():
    assert compute_reward_units(RewardInput(8000)) > 0


def test_higher_quality_should_not_reduce_reward():
    low = compute_reward_units(RewardInput(7000, difficulty=2, verified_seconds=10, reliability=100))
    high = compute_reward_units(RewardInput(9000, difficulty=2, verified_seconds=10, reliability=100))
    assert high >= low


def test_reward_input_is_bounded():
    value = compute_reward_units(RewardInput(99999, difficulty=99999, verified_seconds=999999, reliability=999))
    assert isinstance(value, int)
    assert value > 0
