# Code of Conduct

We are committed to a respectful, technical and open collaboration environment.

Participants are expected to:

- be respectful and constructive;
- critique ideas, not people;
- disclose security issues responsibly;
- document experiments honestly;
- avoid harassment, discrimination and threats.

Maintainers may moderate contributions that violate this standard.
