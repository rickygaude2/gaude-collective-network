# GAUD-E smart contracts

Prototype contracts for the GAUD-E Collective Network.

## Contracts

- `GAUDEToken.sol`: capped ERC-20 test token.
- `ContributionRegistry.sol`: stores compact commitments for verified AI contributions.
- `RewardsVault.sol`: prefunded vault for contributor reward settlement.
- `script/Deploy.s.sol`: local/testnet deployment script.

## Security model

The blockchain stores commitments and settlement state. AI training, inference and validation happen off-chain.

These contracts are **not audited**. Use a development/test wallet and test tokens only.

OpenZeppelin Contracts is used for ERC-20, SafeERC20 and role-based access control. See the official documentation before production deployment.
