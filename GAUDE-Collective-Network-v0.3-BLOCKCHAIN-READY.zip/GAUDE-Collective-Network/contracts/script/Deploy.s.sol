// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

import {Script} from "forge-std/Script.sol";
import {GAUDEToken} from "../GAUDEToken.sol";
import {ContributionRegistry} from "../ContributionRegistry.sol";
import {RewardsVault} from "../RewardsVault.sol";

/// @notice Development deployment. Use a dedicated deployer/test wallet only.
contract Deploy is Script {
    function run() external returns (GAUDEToken token, ContributionRegistry registry, RewardsVault vault) {
        uint256 deployerKey = vm.envUint("DEPLOYER_PRIVATE_KEY");
        address admin = vm.addr(deployerKey);

        vm.startBroadcast(deployerKey);
        token = new GAUDEToken(admin);
        registry = new ContributionRegistry(admin);
        vault = new RewardsVault(admin, token);

        // Fund the reward vault with 1,000,000 GAUDE test tokens.
        token.mint(address(vault), 1_000_000 ether);
        vm.stopBroadcast();
    }
}
