// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {GAUDEToken} from "../GAUDEToken.sol";
import {RewardsVault} from "../RewardsVault.sol";

contract RewardsVaultTest is Test {
    GAUDEToken token;
    RewardsVault vault;
    address admin = address(0xA11CE);
    address worker = address(0xB0B);

    function setUp() public {
        token = new GAUDEToken(admin);
        vault = new RewardsVault(admin, token);
        vm.prank(admin);
        token.mint(address(vault), 1000 ether);
    }

    function testSettleOnce() public {
        vm.prank(admin);
        vault.settle(bytes32(uint256(1)), worker, 100 ether);
        assertEq(token.balanceOf(worker), 100 ether);
        assertTrue(vault.settled(bytes32(uint256(1))));
    }

    function testCannotSettleTwice() public {
        vm.prank(admin);
        vault.settle(bytes32(uint256(1)), worker, 100 ether);
        vm.expectRevert(bytes("job-settled"));
        vm.prank(admin);
        vault.settle(bytes32(uint256(1)), worker, 100 ether);
    }
}
