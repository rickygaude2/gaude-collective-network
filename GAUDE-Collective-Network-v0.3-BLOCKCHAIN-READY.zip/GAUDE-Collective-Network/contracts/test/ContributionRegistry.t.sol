// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

import {Test} from "forge-std/Test.sol";
import {ContributionRegistry} from "../ContributionRegistry.sol";

contract ContributionRegistryTest is Test {
    ContributionRegistry registry;
    address admin = address(0xA11CE);
    address worker = address(0xB0B);

    function setUp() public {
        registry = new ContributionRegistry(admin);
    }

    function testRecordContribution() public {
        vm.prank(admin);
        registry.recordContribution(bytes32(uint256(1)), worker, bytes32(uint256(2)), 8500);
        (address w, bytes32 h, uint256 score, uint64 ts) = registry.contributions(bytes32(uint256(1)));
        assertEq(w, worker);
        assertEq(h, bytes32(uint256(2)));
        assertEq(score, 8500);
        assertGt(ts, 0);
    }

    function testRejectDuplicateJob() public {
        vm.prank(admin);
        registry.recordContribution(bytes32(uint256(1)), worker, bytes32(uint256(2)), 8500);
        vm.expectRevert(bytes("job-recorded"));
        vm.prank(admin);
        registry.recordContribution(bytes32(uint256(1)), worker, bytes32(uint256(3)), 9000);
    }
}
