// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/// @notice Prefunded testnet vault used to settle verified contributor rewards.
/// @dev Production version should add timelocks, epoch budgets, proof validation and multisig control.
contract RewardsVault is AccessControl {
    using SafeERC20 for IERC20;

    bytes32 public constant SETTLER_ROLE = keccak256("SETTLER_ROLE");
    IERC20 public immutable token;
    mapping(bytes32 => bool) public settled;

    event RewardSettled(bytes32 indexed jobId, address indexed worker, uint256 amount);

    constructor(address admin, IERC20 token_) {
        require(admin != address(0), "admin=zero");
        require(address(token_) != address(0), "token=zero");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(SETTLER_ROLE, admin);
        token = token_;
    }

    function settle(bytes32 jobId, address worker, uint256 amount) external onlyRole(SETTLER_ROLE) {
        require(!settled[jobId], "job-settled");
        require(worker != address(0), "worker=zero");
        settled[jobId] = true;
        token.safeTransfer(worker, amount);
        emit RewardSettled(jobId, worker, amount);
    }
}
