// SPDX-License-Identifier: Apache-2.0
pragma solidity ^0.8.24;

import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/// @notice On-chain registry for verified AI contribution receipts.
/// @dev Prototype. The contract stores compact commitments only; heavy ML data stays off-chain.
contract ContributionRegistry is AccessControl {
    bytes32 public constant RECORDER_ROLE = keccak256("RECORDER_ROLE");

    struct Contribution {
        address worker;
        bytes32 receiptHash;
        uint256 qualityScore; // 0..10000 basis points
        uint64 recordedAt;
    }

    mapping(bytes32 => Contribution) public contributions;

    event ContributionRecorded(
        bytes32 indexed jobId,
        address indexed worker,
        bytes32 indexed receiptHash,
        uint256 qualityScore
    );

    constructor(address admin) {
        require(admin != address(0), "admin=zero");
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
        _grantRole(RECORDER_ROLE, admin);
    }

    function recordContribution(
        bytes32 jobId,
        address worker,
        bytes32 receiptHash,
        uint256 qualityScore
    ) external onlyRole(RECORDER_ROLE) {
        require(jobId != bytes32(0), "job=zero");
        require(worker != address(0), "worker=zero");
        require(receiptHash != bytes32(0), "receipt=zero");
        require(qualityScore <= 10000, "score>10000");
        require(contributions[jobId].recordedAt == 0, "job-recorded");

        contributions[jobId] = Contribution({
            worker: worker,
            receiptHash: receiptHash,
            qualityScore: qualityScore,
            recordedAt: uint64(block.timestamp)
        });

        emit ContributionRecorded(jobId, worker, receiptHash, qualityScore);
    }
}
