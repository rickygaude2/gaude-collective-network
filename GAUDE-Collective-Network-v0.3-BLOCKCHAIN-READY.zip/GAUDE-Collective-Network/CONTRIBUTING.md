# Contributing to GAUD-E Collective Network

Thank you for helping build an open collective AI protocol.

## Areas

- AI / ML and federated learning
- distributed systems and P2P
- Ethereum / Solidity / smart-contract security
- cryptographic verification
- energy measurement and efficiency
- protocol economics
- developer tooling
- documentation / UX

## Quick start

```bash
git clone https://github.com/<your-account>/gaude-collective-network.git
cd gaude-collective-network
python -m venv .venv
# activate the venv, then:
pip install -r coordinator/requirements.txt
python -m pytest -q
```

For blockchain work, see [`docs/M1_BLOCKCHAIN.md`](docs/M1_BLOCKCHAIN.md).

## Contribution rule

Please open an Issue before substantial protocol changes. Security-sensitive changes should be discussed privately according to `SECURITY.md`.

## Principle

The project is experimental. Prefer small, reproducible, testable changes over speculative complexity.
