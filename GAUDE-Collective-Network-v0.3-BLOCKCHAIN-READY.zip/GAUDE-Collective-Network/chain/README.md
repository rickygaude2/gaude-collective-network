# GAUD-E Chain Gateway

Small Node.js service that bridges the GAUD-E coordinator to an EVM RPC endpoint.

## Why a separate gateway?

The worker signs its own contribution receipt. The gateway holds the **protocol signer** that has permission to write contribution records and settle test rewards.

```text
Worker key → sign receipt
Protocol key → blockchain transactions
```

Keep both keys separate. Never put either private key in GitHub.

## Commands

```bash
npm install
npm run dev
npm run status
```

## Required environment variables

See `.env.example`.

## API

- `GET /health`
- `POST /contributions/record`
- `POST /rewards/settle`
- `GET /balance/:address`
