import 'dotenv/config';

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing environment variable: ${name}`);
  return value;
}

export function getConfig(requireSigner = false) {
  const cfg = {
    rpcUrl: required('CHAIN_RPC_URL'),
    chainId: Number(process.env.CHAIN_ID || 31337),
    tokenAddress: required('GAUDE_TOKEN_ADDRESS'),
    registryAddress: required('CONTRIBUTION_REGISTRY_ADDRESS'),
    vaultAddress: required('REWARDS_VAULT_ADDRESS'),
    port: Number(process.env.PORT || 8090),
    defaultRewardTokens: process.env.DEFAULT_REWARD_TOKENS || '10',
  };
  if (requireSigner) cfg.privateKey = required('CHAIN_PRIVATE_KEY');
  return cfg;
}
