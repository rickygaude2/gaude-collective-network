import { ChainClient } from './client.mjs';

const cmd = process.argv[2];
const client = new ChainClient();

if (cmd === 'status') {
  console.log(JSON.stringify(await client.status(), null, 2));
} else if (cmd === 'balance') {
  const address = process.env.ADDRESS || process.argv[3];
  if (!address) throw new Error('Set ADDRESS or pass an address');
  console.log(JSON.stringify(await client.balance(address), null, 2));
} else if (cmd === 'record') {
  const [jobId, worker, receiptHash, qualityScore] = process.argv.slice(3);
  console.log(JSON.stringify(await client.recordContribution({ jobId, worker, receiptHash, qualityScore: Number(qualityScore) }), null, 2));
} else if (cmd === 'settle') {
  const [jobId, worker, amountTokens] = process.argv.slice(3);
  console.log(JSON.stringify(await client.settleReward({ jobId, worker, amountTokens }), null, 2));
} else {
  console.error('Usage: node src/cli.mjs status|balance <address>|record <bytes32JobId> <worker> <bytes32ReceiptHash> <qualityScore>|settle <bytes32JobId> <worker> <amountTokens>');
  process.exit(1);
}
