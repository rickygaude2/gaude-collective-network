import express from 'express';
import { ChainClient } from './client.mjs';
import { getConfig } from './config.mjs';

const app = express();
app.use(express.json({ limit: '1mb' }));

const GATEWAY_TOKEN = process.env.CHAIN_GATEWAY_TOKEN || '';
function authorize(req, res, next) {
  if (!GATEWAY_TOKEN) return next();
  if (req.get('x-gaude-gateway-token') !== GATEWAY_TOKEN) {
    return res.status(401).json({ ok: false, error: 'unauthorized' });
  }
  next();
}
app.use('/contributions', authorize);
app.use('/rewards', authorize);

let client;
function getClient() {
  if (!client) client = new ChainClient();
  return client;
}

app.get('/health', async (_req, res) => {
  try {
    const status = await getClient().status();
    res.json({ ok: true, service: 'gaude-chain-gateway', ...status });
  } catch (error) {
    res.status(503).json({ ok: false, error: error.message });
  }
});

app.post('/contributions/record', async (req, res) => {
  try {
    const { jobId, worker, receiptHash, qualityScore } = req.body;
    if (!jobId || !worker || !receiptHash || qualityScore === undefined) {
      return res.status(400).json({ error: 'jobId, worker, receiptHash and qualityScore are required' });
    }
    const result = await getClient().recordContribution({ jobId, worker, receiptHash, qualityScore });
    res.json({ ok: true, ...result });
  } catch (error) {
    res.status(502).json({ ok: false, error: error.shortMessage || error.message });
  }
});

app.post('/rewards/settle', async (req, res) => {
  try {
    const cfg = getConfig(false);
    const { jobId, worker, amountTokens } = req.body;
    const amount = amountTokens ?? cfg.defaultRewardTokens;
    if (!jobId || !worker) return res.status(400).json({ error: 'jobId and worker are required' });
    const result = await getClient().settleReward({ jobId, worker, amountTokens: amount });
    res.json({ ok: true, ...result, amountTokens: amount });
  } catch (error) {
    res.status(502).json({ ok: false, error: error.shortMessage || error.message });
  }
});

app.get('/balance/:address', async (req, res) => {
  try {
    if (!/^0x[a-fA-F0-9]{40}$/.test(req.params.address)) return res.status(400).json({ error: 'invalid address' });
    res.json({ ok: true, ...(await getClient().balance(req.params.address)) });
  } catch (error) {
    res.status(502).json({ ok: false, error: error.message });
  }
});

const port = Number(process.env.PORT || 8090);
app.listen(port, '0.0.0.0', () => {
  console.log(`GAUD-E chain gateway listening on http://127.0.0.1:${port}`);
});
