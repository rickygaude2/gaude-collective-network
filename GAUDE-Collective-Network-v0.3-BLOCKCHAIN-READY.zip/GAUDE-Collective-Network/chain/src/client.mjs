import { ethers } from 'ethers';
import { getConfig } from './config.mjs';
import tokenAbi from '../abi/GAUDEToken.json' with { type: 'json' };
import registryAbi from '../abi/ContributionRegistry.json' with { type: 'json' };
import vaultAbi from '../abi/RewardsVault.json' with { type: 'json' };

export class ChainClient {
  constructor() {
    const cfg = getConfig(true);
    this.cfg = cfg;
    this.provider = new ethers.JsonRpcProvider(cfg.rpcUrl, cfg.chainId);
    this.wallet = new ethers.Wallet(cfg.privateKey, this.provider);
    this.token = new ethers.Contract(cfg.tokenAddress, tokenAbi, this.wallet);
    this.registry = new ethers.Contract(cfg.registryAddress, registryAbi, this.wallet);
    this.vault = new ethers.Contract(cfg.vaultAddress, vaultAbi, this.wallet);
  }

  async status() {
    const network = await this.provider.getNetwork();
    const block = await this.provider.getBlockNumber();
    const balance = await this.provider.getBalance(this.wallet.address);
    const tokenBalance = await this.token.balanceOf(this.wallet.address);
    return {
      rpcUrl: this.cfg.rpcUrl,
      chainId: Number(network.chainId),
      block,
      signer: this.wallet.address,
      nativeBalance: balance.toString(),
      gaudeBalance: ethers.formatUnits(tokenBalance, await this.token.decimals()),
    };
  }

  async recordContribution({ jobId, worker, receiptHash, qualityScore }) {
    const tx = await this.registry.recordContribution(jobId, worker, receiptHash, qualityScore);
    const receipt = await tx.wait();
    return { txHash: tx.hash, blockNumber: receipt.blockNumber };
  }

  async settleReward({ jobId, worker, amountTokens }) {
    const decimals = await this.token.decimals();
    const amount = ethers.parseUnits(String(amountTokens), decimals);
    const tx = await this.vault.settle(jobId, worker, amount);
    const receipt = await tx.wait();
    return { txHash: tx.hash, blockNumber: receipt.blockNumber, amount: amount.toString() };
  }

  async balance(address) {
    const decimals = await this.token.decimals();
    const value = await this.token.balanceOf(address);
    return { address, balance: ethers.formatUnits(value, decimals) };
  }
}
