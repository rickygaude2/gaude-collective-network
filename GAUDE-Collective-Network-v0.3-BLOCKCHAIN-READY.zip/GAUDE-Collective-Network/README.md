# GAUD-E Collective Network

> **One Global AI. Built by Everyone. For Everyone.**

Open-source protocol research for building a globally distributed **collective AI**: one evolving intelligence that can be trained, evaluated and operated by a community rather than by a single infrastructure provider.

![GAUD-E Architecture](website/assets/gaude-architecture.png)

## What changed in M1

This repository now contains a blockchain-connected prototype loop:

```text
Worker
  ↓
signed AI contribution receipt
  ↓
Coordinator
  ↓
verification
  ↓
Chain Gateway
  ↓
ContributionRegistry
  ↓
RewardsVault
  ↓
GAUDE test reward
```

The blockchain stores compact hashes, contribution records and settlement state. Heavy AI computation remains off-chain.

## Project vision

GAUD-E is **not** a project to give every user a separate AI. The goal is a shared collective intelligence that is improved by many independent contributors:

- developers contribute code;
- GPU/CPU operators contribute compute;
- researchers contribute training methods;
- participants contribute evaluation and feedback;
- organizations contribute infrastructure and authorized datasets;
- validators verify that work is real and useful.

The long-term research goal is a network where useful verified contributions improve a shared model and where the network can use a transparent economic layer to reward participants.

## M1 components

### AI Worker

`node/worker.py` registers hardware, receives a job, performs a deterministic benchmark and signs the resulting receipt with an EVM wallet.

### Coordinator

`coordinator/app.py` provides job scheduling, worker registration, receipt verification, persistence and optional on-chain settlement.

### Chain Gateway

`chain/` is a Node.js service using ethers that connects the coordinator to an EVM RPC endpoint and submits transactions to the protocol contracts.

### Smart contracts

- `GAUDEToken.sol` — capped ERC-20 test token.
- `ContributionRegistry.sol` — contribution commitments.
- `RewardsVault.sol` — prefunded contributor rewards.

These contracts use OpenZeppelin components and are **unaudited prototypes**. OpenZeppelin's current Contracts documentation covers ERC-20, SafeERC20 and role-based access control. citeturn109414search1turn109414search0

## Run the off-chain MVP

Requirements: Python 3.11+

```bash
python -m venv .venv
# activate the virtual environment
pip install -r coordinator/requirements.txt
uvicorn coordinator.app:app --reload --port 8080
```

In another terminal:

```bash
export WORKER_PRIVATE_KEY=<development-wallet-private-key>
python node/worker.py --coordinator http://127.0.0.1:8080 --name worker-01
```

## Run blockchain-connected local development

See [`docs/M1_BLOCKCHAIN.md`](docs/M1_BLOCKCHAIN.md) and [`docs/ROADMAP_M1_TO_M2.md`](docs/ROADMAP_M1_TO_M2.md).

Short version:

```bash
anvil
./scripts/setup_foundry.sh
export DEPLOYER_PRIVATE_KEY=<anvil-test-key>
forge script contracts/script/Deploy.s.sol --rpc-url http://127.0.0.1:8545 --broadcast
```

Copy the deployed addresses into `chain/.env`, then:

```bash
cd chain
cp .env.example .env
npm install
npm run dev
```

In a new terminal, start the coordinator with `CHAIN_GATEWAY_URL=http://127.0.0.1:8090` and then run the worker using a development wallet.

## Tests

Python:

```bash
python -m pytest -q
```

Solidity (with Foundry + dependencies installed):

```bash
forge test -vv
```

## Roadmap

### M1 — now

- signed contribution receipts
- EVM connection
- on-chain contribution registry
- prefunded test rewards
- persistent coordinator state
- GPU detection

### M2

- real federated learning
- independent validator nodes
- challenge/dispute flow
- P2P discovery
- contribution benchmarks

### M3

- real distributed RL / MoE experiments
- cryptographic proofs for selected workloads
- energy and carbon accounting
- public testnet

### M4

- collective model registry
- governance
- production-grade economic design
- multi-region infrastructure

## Security

Do not use a production wallet. Do not commit private keys. See [`SECURITY.md`](SECURITY.md).

## License

Apache-2.0.
