---
name: Good first issue
about: Small task suitable for a new contributor
labels: "good first issue"
---

## Task

## Why it matters

## Acceptance criteria
