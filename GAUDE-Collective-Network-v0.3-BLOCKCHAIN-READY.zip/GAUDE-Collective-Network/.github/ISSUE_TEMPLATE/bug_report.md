---
name: Bug report
about: Report a reproducible problem
labels: bug
---

## What happened?

## Steps to reproduce

## Environment

- OS:
- Python:
- GPU (if any):
- Commit:

## Logs / screenshots
