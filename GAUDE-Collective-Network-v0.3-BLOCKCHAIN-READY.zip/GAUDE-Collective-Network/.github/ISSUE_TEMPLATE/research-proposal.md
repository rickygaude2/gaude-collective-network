---
name: Research proposal
aabout: Propose a research direction for GAUD-E
labels: research
---

## Research question

## Why it matters

## Proposed experiment

## Metrics / benchmark

## Risks or failure modes

## References
