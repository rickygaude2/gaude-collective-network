---
name: Feature request
about: Propose a feature or protocol improvement
labels: enhancement
---

## Problem

What problem should GAUD-E solve?

## Proposed solution

Describe the idea.

## Protocol impact

Does it affect compute scheduling, verification, privacy, blockchain, tokenomics or governance?

## Alternatives considered

What other approaches did you consider?
