"""Shared GAUD-E protocol primitives."""
