from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class RewardInput:
    quality_score: int  # 0..10000
    difficulty: int = 1
    verified_seconds: int = 1
    reliability: int = 100  # 0..100


def compute_reward_units(data: RewardInput) -> int:
    """Transparent prototype reward function.

    This is not a tokenomics finalization. It exists so contributors can
    experiment with a deterministic, auditable reward policy.
    """
    quality = max(0, min(10000, data.quality_score)) / 10000
    difficulty = max(1, min(1000, data.difficulty))
    reliability = max(0, min(100, data.reliability)) / 100
    seconds = max(1, min(86400, data.verified_seconds))
    raw = quality * difficulty * reliability * (seconds ** 0.5) * 10
    return max(1, int(round(raw)))
