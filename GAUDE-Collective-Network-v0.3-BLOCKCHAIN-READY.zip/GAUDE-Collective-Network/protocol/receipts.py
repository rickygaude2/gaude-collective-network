from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from protocol.hashing import sha256_json


@dataclass(frozen=True)
class ContributionReceipt:
    job_id: str
    model_hash: str
    dataset_hash: str
    worker_id: str
    metrics: dict[str, float]
    started_at: float
    completed_at: float
    result_hash: str

    def body(self) -> dict[str, Any]:
        return asdict(self)

    def receipt_hash(self) -> str:
        return sha256_json(self.body())
