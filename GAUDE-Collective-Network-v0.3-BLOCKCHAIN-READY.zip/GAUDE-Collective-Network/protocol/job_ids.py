from __future__ import annotations

import hashlib


def job_id_bytes32(job_id: str) -> str:
    """Return a 32-byte hex identifier suitable for Solidity bytes32."""
    return "0x" + hashlib.sha256(job_id.encode("utf-8")).hexdigest()


def receipt_hash_bytes32(receipt_hash: str) -> str:
    value = receipt_hash.removeprefix("0x")
    if len(value) == 64:
        int(value, 16)
        return "0x" + value
    return "0x" + hashlib.sha256(receipt_hash.encode("utf-8")).hexdigest()
