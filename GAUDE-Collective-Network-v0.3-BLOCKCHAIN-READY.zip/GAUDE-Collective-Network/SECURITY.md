# Security Policy

GAUD-E is research software. Do not use the prototype contracts or coordinator for production value or sensitive data.

## Reporting a vulnerability

Please do not publish an unpatched critical vulnerability as a public issue first. Open a private security report through the repository's security contact mechanism once enabled.

Never commit:

- private keys;
- API keys;
- passwords;
- personal data;
- proprietary training data without authorization.

Smart contracts must be independently audited before any mainnet deployment or meaningful funds are placed under their control.
