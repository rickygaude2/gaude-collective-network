const translations = {
  en: {
    navVision:'Vision',navArchitecture:'Architecture',navContribute:'Contribute',navRoadmap:'Roadmap',navCode:'Code',githubButton:'GitHub',
    eyebrow:'OPEN-SOURCE • DISTRIBUTED AI • COMMUNITY RESEARCH',
    heroTitle:'One Global AI.<br><span>Built by Everyone.</span><br>For Everyone.',
    heroLead:'GAUD-E explores a new model for artificial intelligence: one collective intelligence continuously improved by people, researchers, companies and machines around the world.',
    startContributing:'Start contributing',readProject:'Read the project',
    heroNote:'Prototype stage: the network is being built in public. The model, verification system and token economy are experimental.',
    statNodes:'prototype nodes',statContributors:'contributors targeted',statRounds:'collective rounds demo',statCode:'source code',
    sectionArchitecture:'01 / ARCHITECTURE',architectureTitle:'A simple idea: many machines, one evolving intelligence.',
    architectureLead:'Blockchain coordinates and records trust. The heavy AI computation stays off-chain and is distributed across participating machines.',
    sectionMap:'02 / SYSTEM MAP',mapTitle:'The whole system at a glance.',mapLead:'This diagram is a research architecture, not a claim that every layer is already production-ready.',
    why1Title:'One collective model',why1Body:'Participants help improve the same shared AI system instead of creating isolated private models.',
    why2Title:'Use idle resources',why2Body:'The network can coordinate spare GPUs, CPUs, storage and bandwidth that would otherwise sit unused.',
    why3Title:'Verify useful work',why3Body:'Contribution should be measured by useful, verifiable work rather than simply by owning more hardware.',
    why4Title:'Build in public',why4Body:'Code, research, benchmarks and protocol decisions are intended to be open for the community to inspect and improve.',
    sectionContribute:'03 / JOIN THE BUILD',contributeTitle:'You do not need a huge data center to help.',
    contributeLead:'Developers, AI researchers, distributed-systems engineers, blockchain builders, security researchers, economists, designers and students can all contribute.',
    contribCode:'Workers, APIs, tests and tooling',contribResearch:'Proof-of-AI-Contribution, federated learning and verification',contribProtocol:'Token, settlement and governance prototypes',contribCommunity:'Docs, outreach, feedback and onboarding',
    sectionRoadmap:'04 / ROADMAP',roadmapTitle:'From a public prototype to a global network.',
    step1:'Worker, coordinator, receipts and collective-learning demo.',step2:'GPU-aware worker and real open-model inference/training experiments.',step3:'Peer discovery, validation, reputation and proof experiments.',step4:'Public testnet, explorer and contributor rewards.',step5:'A reproducible shared model trained across independent nodes.',
    manifesto:'We are exploring whether intelligence can become a public, open and collectively built infrastructure — powered by many contributors instead of a single center.',
    manifestoNote:'GAUD-E is an open research project. It is not currently a live global AI network and the GAUDE token is only a prototype/testnet concept.'
  },
  es: {
    navVision:'Visión',navArchitecture:'Arquitectura',navContribute:'Contribuir',navRoadmap:'Hoja de ruta',navCode:'Código',githubButton:'GitHub',
    eyebrow:'CÓDIGO ABIERTO • IA DISTRIBUIDA • INVESTIGACIÓN COMUNITARIA',
    heroTitle:'Una IA Global.<br><span>Construida por Todos.</span><br>Para Todos.',
    heroLead:'GAUD-E explora un nuevo modelo de inteligencia artificial: una inteligencia colectiva que mejora continuamente con personas, investigadores, empresas y máquinas de todo el mundo.',
    startContributing:'Comenzar a contribuir',readProject:'Leer el proyecto',
    heroNote:'Etapa prototipo: la red se está construyendo públicamente. El modelo, la verificación y la economía del token son experimentales.',
    statNodes:'nodos de prototipo',statContributors:'colaboradores objetivo',statRounds:'rondas colectivas demo',statCode:'código abierto',
    sectionArchitecture:'01 / ARQUITECTURA',architectureTitle:'Una idea simple: muchas máquinas, una inteligencia que evoluciona.',
    architectureLead:'La blockchain coordina y registra confianza. El cálculo pesado de IA permanece fuera de cadena y se distribuye entre las máquinas participantes.',
    sectionMap:'02 / MAPA DEL SISTEMA',mapTitle:'Todo el sistema de un vistazo.',mapLead:'Este esquema es una arquitectura de investigación; no afirma que todas las capas estén listas para producción.',
    why1Title:'Un modelo colectivo',why1Body:'Los participantes ayudan a mejorar el mismo sistema de IA compartido en lugar de crear IAs privadas aisladas.',
    why2Title:'Aprovechar recursos ociosos',why2Body:'La red puede coordinar GPUs, CPUs, almacenamiento y ancho de banda que de otro modo quedarían sin usar.',
    why3Title:'Verificar trabajo útil',why3Body:'La contribución debería medirse por trabajo útil y verificable, no simplemente por tener más hardware.',
    why4Title:'Construir en público',why4Body:'Código, investigación, benchmarks y decisiones del protocolo deben poder ser revisados y mejorados por la comunidad.',
    sectionContribute:'03 / ÚNETE A LA CONSTRUCCIÓN',contributeTitle:'No necesitas un gran centro de datos para ayudar.',
    contributeLead:'Programadores, investigadores de IA, especialistas en sistemas distribuidos, blockchain, seguridad, economía, diseño y estudiantes pueden contribuir.',
    contribCode:'Workers, APIs, tests y herramientas',contribResearch:'Proof-of-AI-Contribution, aprendizaje federado y verificación',contribProtocol:'Prototipos de token, liquidación y gobernanza',contribCommunity:'Documentación, difusión, feedback y onboarding',
    sectionRoadmap:'04 / HOJA DE RUTA',roadmapTitle:'De un prototipo público a una red global.',
    step1:'Worker, coordinador, recibos y demo de aprendizaje colectivo.',step2:'Worker consciente de GPU y experimentos de inferencia/entrenamiento con modelos abiertos.',step3:'Descubrimiento P2P, validación, reputación y pruebas.',step4:'Testnet pública, explorador y recompensas para contribuidores.',step5:'Un modelo compartido reproducible entrenado entre nodos independientes.',
    manifesto:'Exploramos si la inteligencia puede convertirse en una infraestructura pública, abierta y construida colectivamente, impulsada por muchos participantes en lugar de un único centro.',
    manifestoNote:'GAUD-E es un proyecto de investigación abierto. Actualmente no es una red global de IA en producción y el token GAUDE es sólo un concepto de prototipo/testnet.'
  }
};
let lang='en';
function renderLanguage(){
  const dict=translations[lang];
  document.documentElement.lang=lang;
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key=el.dataset.i18n;
    if(dict[key]!==undefined) el.innerHTML=dict[key];
  });
  document.getElementById('langToggle').textContent=lang==='en'?'ES':'EN';
}
document.getElementById('langToggle').addEventListener('click',()=>{lang=lang==='en'?'es':'en';renderLanguage();});
renderLanguage();

