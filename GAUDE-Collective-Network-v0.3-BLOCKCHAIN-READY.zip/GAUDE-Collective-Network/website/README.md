# GAUD-E website

Static landing page for the GAUD-E Collective Network.

Run locally:

```bash
python -m http.server 4173 --directory website
```

Open http://127.0.0.1:4173/
