#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python node/collective_learning.py --rounds "${GAUDE_ROUNDS:-5}" --clients "${GAUDE_CLIENTS:-8}" --samples "${GAUDE_SAMPLES:-120}"
