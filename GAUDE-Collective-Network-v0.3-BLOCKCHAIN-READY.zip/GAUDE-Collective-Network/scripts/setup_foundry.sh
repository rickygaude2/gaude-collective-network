#!/usr/bin/env bash
set -euo pipefail
if ! command -v forge >/dev/null 2>&1; then
  echo "Forge is required. Install Foundry first: https://book.getfoundry.sh/getting-started/installation"
  exit 1
fi
forge install OpenZeppelin/openzeppelin-contracts --no-commit
forge install foundry-rs/forge-std --no-commit
printf "OpenZeppelin and forge-std installed.\n"
