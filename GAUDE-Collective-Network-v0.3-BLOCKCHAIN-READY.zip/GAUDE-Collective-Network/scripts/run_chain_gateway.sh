#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../chain"
if [ ! -d node_modules ]; then
  npm install
fi
node src/server.mjs
