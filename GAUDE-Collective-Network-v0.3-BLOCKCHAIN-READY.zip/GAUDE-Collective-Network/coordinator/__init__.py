"""GAUD-E coordinator package."""
