from __future__ import annotations

import os
import sqlite3
import time
import uuid
from contextlib import closing
from hashlib import sha256
from pathlib import Path
from typing import Any

import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from protocol.hashing import sha256_json
from protocol.job_ids import job_id_bytes32, receipt_hash_bytes32
from protocol.reward_policy import RewardInput, compute_reward_units
from node.receipt_signing import verify_receipt

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.getenv("GAUDE_DB", str(ROOT / "gaude.db")))
CHAIN_GATEWAY_URL = os.getenv("CHAIN_GATEWAY_URL", "").rstrip("/")
CHAIN_GATEWAY_TOKEN = os.getenv("CHAIN_GATEWAY_TOKEN", "")
MIN_QUALITY_SCORE = int(os.getenv("MIN_QUALITY_SCORE", "7000"))
DEFAULT_REWARD_TOKENS = os.getenv("DEFAULT_REWARD_TOKENS", "10")

app = FastAPI(title="GAUD-E Collective Coordinator", version="0.3.0")


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    with closing(db()) as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS workers (
                name TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                registered_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS jobs (
                job_id TEXT PRIMARY KEY,
                payload TEXT NOT NULL,
                status TEXT NOT NULL,
                created_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS completions (
                job_id TEXT PRIMARY KEY,
                worker TEXT NOT NULL,
                receipt_hash TEXT NOT NULL,
                signer TEXT,
                payload TEXT NOT NULL,
                quality_score INTEGER NOT NULL,
                accepted_at REAL NOT NULL,
                onchain_tx TEXT,
                reward_tx TEXT
            );
            """
        )
        conn.commit()


def startup() -> None:
    init_db()
    with closing(db()) as conn:
        row = conn.execute("SELECT COUNT(*) AS n FROM jobs").fetchone()
        if row["n"] == 0:
            create_demo_job(conn)



def create_demo_job(conn: sqlite3.Connection) -> None:
    job_id = f"job-{uuid.uuid4().hex[:12]}"
    model_hash = sha256(b"gaude-collective-model-m1-demo").hexdigest()
    dataset_hash = sha256(b"gaude-collective-dataset-m1-demo").hexdigest()
    payload = {
        "job_id": job_id,
        "model_hash": model_hash,
        "dataset_hash": dataset_hash,
        "kind": "collective_ai_benchmark",
        "difficulty": 2,
        "reward_tokens": DEFAULT_REWARD_TOKENS,
    }
    import json

    conn.execute(
        "INSERT INTO jobs(job_id,payload,status,created_at) VALUES(?,?,?,?)",
        (job_id, json.dumps(payload), "open", time.time()),
    )
    conn.commit()


# Initialize immediately so CLI/test clients that do not enter an ASGI
# lifespan context still get a usable database.
startup()


class WorkerRegistration(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    hostname: str = Field(min_length=1, max_length=200)
    platform: str = Field(min_length=1, max_length=300)
    cpu_count: int = Field(ge=1, le=4096)
    memory_gb: float = Field(gt=0, le=100000)
    gpu_name: str | None = Field(default=None, max_length=200)
    gpu_vram_gb: float | None = Field(default=None, ge=0, le=1000)
    wallet_address: str | None = Field(default=None, max_length=64)


class JobCreate(BaseModel):
    kind: str = Field(default="collective_ai_benchmark", min_length=1, max_length=80)
    model_hash: str = Field(min_length=64, max_length=128)
    dataset_hash: str = Field(min_length=64, max_length=128)
    difficulty: int = Field(default=1, ge=1, le=1000)
    reward_tokens: str = Field(default=DEFAULT_REWARD_TOKENS, max_length=40)


def chain_headers() -> dict[str, str]:
    return {"x-gaude-gateway-token": CHAIN_GATEWAY_TOKEN} if CHAIN_GATEWAY_TOKEN else {}


def json_dump(value: Any) -> str:
    import json
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


@app.get("/")
def root() -> dict[str, Any]:
    with closing(db()) as conn:
        workers = conn.execute("SELECT COUNT(*) n FROM workers").fetchone()["n"]
        jobs = conn.execute("SELECT COUNT(*) n FROM jobs WHERE status='open'").fetchone()["n"]
    return {
        "project": "GAUD-E Collective Network",
        "status": "m1-protocol-alpha",
        "workers": workers,
        "open_jobs": jobs,
        "onchain_enabled": bool(CHAIN_GATEWAY_URL),
    }


@app.get("/health")
def health() -> dict[str, Any]:
    chain = None
    if CHAIN_GATEWAY_URL:
        try:
            chain = requests.get(f"{CHAIN_GATEWAY_URL}/health", headers=chain_headers(), timeout=5).json()
        except requests.RequestException as exc:
            chain = {"ok": False, "error": str(exc)}
    return {"ok": True, "chain": chain}


@app.post("/workers/register")
def register_worker(payload: WorkerRegistration) -> dict[str, Any]:
    with closing(db()) as conn:
        conn.execute(
            "INSERT OR REPLACE INTO workers(name,payload,registered_at) VALUES(?,?,?)",
            (payload.name, json_dump(payload.model_dump()), time.time()),
        )
        conn.commit()
    return {"status": "registered", "worker": payload.name}


@app.get("/workers")
def list_workers() -> dict[str, Any]:
    import json
    with closing(db()) as conn:
        rows = conn.execute("SELECT payload FROM workers ORDER BY registered_at DESC").fetchall()
    return {"workers": [json.loads(r["payload"]) for r in rows]}


@app.post("/jobs")
def create_job(payload: JobCreate) -> dict[str, Any]:
    job_id = f"job-{uuid.uuid4().hex[:12]}"
    job = {"job_id": job_id, **payload.model_dump()}
    with closing(db()) as conn:
        import json
        conn.execute(
            "INSERT INTO jobs(job_id,payload,status,created_at) VALUES(?,?,?,?)",
            (job_id, json.dumps(job), "open", time.time()),
        )
        conn.commit()
    return job


@app.get("/jobs/next")
def next_job(worker: str | None = None) -> dict[str, Any]:
    import json
    with closing(db()) as conn:
        row = conn.execute("SELECT payload FROM jobs WHERE status='open' ORDER BY created_at LIMIT 1").fetchone()
        if not row:
            return {"status": "empty"}
        return json.loads(row["payload"])


@app.post("/jobs/{job_id}/complete")
def complete_job(job_id: str, receipt: dict[str, Any]) -> dict[str, Any]:
    import json
    with closing(db()) as conn:
        job_row = conn.execute("SELECT payload,status FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        if not job_row:
            raise HTTPException(status_code=404, detail="unknown job")
        if job_row["status"] != "open":
            raise HTTPException(status_code=409, detail="job-not-open")

        try:
            job = json.loads(job_row["payload"])
            signer = receipt.get("signer")
            signature = receipt.get("signature")
            signed_body = receipt.get("signed_body")
            if not signer or not signature or not isinstance(signed_body, dict):
                raise ValueError("missing signed_body/signer/signature")
            if signed_body.get("job_id") != job_id:
                raise ValueError("job mismatch")
            recovered = verify_receipt(signed_body, signature, signer)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"invalid receipt: {exc}") from exc

        quality_score = int(receipt.get("quality_score", 0))
        if quality_score < MIN_QUALITY_SCORE:
            raise HTTPException(status_code=400, detail="quality score below threshold")

        receipt_hash = receipt.get("receipt_hash") or sha256_json(signed_body)
        difficulty = int(job.get("difficulty", 1))
        duration = int(receipt.get("verified_seconds", 1))
        reliability = int(receipt.get("reliability", 100))
        units = compute_reward_units(RewardInput(quality_score, difficulty, duration, reliability))

        import json as _json
        chain_tx = None
        reward_tx = None
        if CHAIN_GATEWAY_URL:
            payload = {
                "jobId": job_id_bytes32(job_id),
                "worker": recovered,
                "receiptHash": receipt_hash_bytes32(receipt_hash),
                "qualityScore": quality_score,
            }
            try:
                chain_response = requests.post(f"{CHAIN_GATEWAY_URL}/contributions/record", json=payload, headers=chain_headers(), timeout=60)
                chain_response.raise_for_status()
                chain_tx = chain_response.json().get("txHash")

                reward_amount = job.get("reward_tokens", DEFAULT_REWARD_TOKENS)
                reward_response = requests.post(
                    f"{CHAIN_GATEWAY_URL}/rewards/settle",
                    headers=chain_headers(),
                    json={
                        "jobId": job_id_bytes32(job_id),
                        "worker": recovered,
                        "amountTokens": reward_amount,
                    },
                    timeout=60,
                )
                reward_response.raise_for_status()
                reward_tx = reward_response.json().get("txHash")
            except requests.RequestException as exc:
                raise HTTPException(status_code=502, detail=f"on-chain settlement failed: {exc}") from exc

        conn.execute(
            "INSERT INTO completions(job_id,worker,receipt_hash,signer,payload,quality_score,accepted_at,onchain_tx,reward_tx) VALUES(?,?,?,?,?,?,?,?,?)",
            (job_id, receipt.get("worker_name", recovered), receipt_hash, recovered, _json.dumps(receipt), quality_score, time.time(), chain_tx, reward_tx),
        )
        conn.execute("UPDATE jobs SET status='completed' WHERE job_id=?", (job_id,))
        conn.commit()

    return {
        "status": "accepted",
        "job_id": job_id,
        "signer": recovered,
        "receipt_hash": receipt_hash,
        "reward_units": units,
        "onchain_contribution_tx": chain_tx,
        "onchain_reward_tx": reward_tx,
    }


@app.get("/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    import json
    with closing(db()) as conn:
        job = conn.execute("SELECT payload,status,created_at FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        completion = conn.execute("SELECT payload,quality_score,onchain_tx,reward_tx FROM completions WHERE job_id=?", (job_id,)).fetchone()
    if not job:
        raise HTTPException(status_code=404, detail="unknown job")
    return {
        "job": json.loads(job["payload"]),
        "status": job["status"],
        "completion": json.loads(completion["payload"]) if completion else None,
        "quality_score": completion["quality_score"] if completion else None,
        "onchain_contribution_tx": completion["onchain_tx"] if completion else None,
        "onchain_reward_tx": completion["reward_tx"] if completion else None,
    }
