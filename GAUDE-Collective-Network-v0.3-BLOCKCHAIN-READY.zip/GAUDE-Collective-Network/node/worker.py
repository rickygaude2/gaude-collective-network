#!/usr/bin/env python3
"""GAUD-E M1 worker.

M1 adds:
- hardware registration
- signed contribution receipts (EVM wallet)
- optional on-chain settlement via the coordinator's chain gateway

The worker still runs a lightweight deterministic benchmark. Real distributed
training is the next milestone and can reuse the same receipt protocol.
"""
from __future__ import annotations

import argparse
import os
import platform
import socket
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import psutil
import requests

from node.receipt_signing import sign_receipt
from protocol.hashing import sha256_json


@dataclass
class WorkerInfo:
    name: str
    hostname: str
    platform: str
    cpu_count: int
    memory_gb: float
    gpu_name: str | None = None
    gpu_vram_gb: float | None = None
    wallet_address: str | None = None


def detect_gpu() -> tuple[str | None, float | None]:
    # Safe, dependency-free NVIDIA detection. Future versions can use NVML.
    import shutil
    import subprocess
    if not shutil.which("nvidia-smi"):
        return None, None
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            text=True,
            timeout=5,
        ).splitlines()[0]
        name, vram = [part.strip() for part in out.split(",", 1)]
        return name, float(vram) / 1024
    except Exception:
        return None, None


def hardware(name: str, wallet_address: str | None) -> WorkerInfo:
    gpu_name, gpu_vram = detect_gpu()
    return WorkerInfo(
        name=name,
        hostname=socket.gethostname(),
        platform=platform.platform(),
        cpu_count=psutil.cpu_count(logical=True) or 1,
        memory_gb=round(psutil.virtual_memory().total / (1024**3), 2),
        gpu_name=gpu_name,
        gpu_vram_gb=round(gpu_vram, 2) if gpu_vram else None,
        wallet_address=wallet_address,
    )


def build_receipt(job: dict, info: WorkerInfo) -> tuple[dict, int, int]:
    started = time.time()
    # Deterministic M1 benchmark placeholder: replace with real ML workload later.
    iterations = 100_000
    accumulator = 0
    for i in range(iterations):
        accumulator = (accumulator + (i * 17) % 9973) % 1_000_003
    finished = time.time()
    duration = max(1, int(round(finished - started)))
    quality_score = 8500
    body = {
        "job_id": job["job_id"],
        "model_hash": job["model_hash"],
        "dataset_hash": job["dataset_hash"],
        "worker": asdict(info),
        "started_at": started,
        "completed_at": finished,
        "verified_seconds": duration,
        "reliability": 100,
        "metrics": {
            "iterations": iterations,
            "accumulator": accumulator,
            "quality_score": quality_score,
        },
    }
    return body, quality_score, duration


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a GAUD-E worker")
    parser.add_argument("--coordinator", default=os.getenv("COORDINATOR_URL", "http://127.0.0.1:8080"))
    parser.add_argument("--name", default=socket.gethostname())
    parser.add_argument("--private-key", default=os.getenv("WORKER_PRIVATE_KEY"))
    args = parser.parse_args()

    wallet_address = None
    if args.private_key:
        try:
            from eth_account import Account
            wallet_address = Account.from_key(args.private_key).address
        except Exception as exc:
            raise SystemExit(f"Invalid WORKER_PRIVATE_KEY: {exc}") from exc

    info = hardware(args.name, wallet_address)
    session = requests.Session()
    session.post(f"{args.coordinator}/workers/register", json=asdict(info), timeout=10).raise_for_status()
    job_response = session.get(f"{args.coordinator}/jobs/next", params={"worker": args.name}, timeout=10)
    job_response.raise_for_status()
    job = job_response.json()
    if job.get("status") == "empty":
        print("No jobs available.")
        return

    signed_body, quality_score, duration = build_receipt(job, info)
    receipt_hash = sha256_json(signed_body)

    payload: dict = {
        "worker_name": info.name,
        "receipt_hash": receipt_hash,
        "quality_score": quality_score,
        "verified_seconds": duration,
        "reliability": 100,
        "signed_body": signed_body,
    }
    if not args.private_key:
        raise SystemExit("WORKER_PRIVATE_KEY is required for M1 signed receipts")
    signer, signature = sign_receipt(signed_body, args.private_key)
    payload["signer"] = signer
    payload["signature"] = signature

    response = session.post(
        f"{args.coordinator}/jobs/{job['job_id']}/complete",
        json=payload,
        timeout=120,
    )
    response.raise_for_status()
    print(response.json())


if __name__ == "__main__":
    main()
