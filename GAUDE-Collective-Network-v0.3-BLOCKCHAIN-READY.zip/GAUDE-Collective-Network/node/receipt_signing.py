#!/usr/bin/env python3
"""Optional EVM receipt signing for a worker wallet.

The signer key stays on the worker. The coordinator receives only the public
address + signature and verifies the signed canonical receipt.
"""
from __future__ import annotations

import json
from typing import Any


def canonical_bytes(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_receipt(payload: dict[str, Any], private_key: str) -> tuple[str, str]:
    try:
        from eth_account import Account
        from eth_account.messages import encode_defunct
    except ImportError as exc:
        raise RuntimeError("Install eth-account to sign worker receipts: pip install eth-account") from exc

    message = encode_defunct(text=canonical_bytes(payload).decode("utf-8"))
    signed = Account.sign_message(message, private_key=private_key)
    return signed.address, signed.signature.hex()


def verify_receipt(payload: dict[str, Any], signature: str, expected_address: str | None = None) -> str:
    try:
        from eth_account import Account
        from eth_account.messages import encode_defunct
    except ImportError as exc:
        raise RuntimeError("Install eth-account to verify worker receipts: pip install eth-account") from exc

    message = encode_defunct(text=canonical_bytes(payload).decode("utf-8"))
    recovered = Account.recover_message(message, signature=signature)
    if expected_address and recovered.lower() != expected_address.lower():
        raise ValueError("signature does not match worker address")
    return recovered
