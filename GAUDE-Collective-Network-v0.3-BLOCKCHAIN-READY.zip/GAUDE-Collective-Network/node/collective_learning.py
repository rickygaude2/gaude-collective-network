#!/usr/bin/env python3
"""Tiny educational federated-learning simulation.

This demo intentionally uses only the Python standard library. Each client
trains a tiny logistic-regression-like model on a synthetic local dataset,
then the server averages parameter deltas. It is a protocol teaching tool,
not production federated learning and not a privacy guarantee.
"""
from __future__ import annotations

import argparse
import math
import random
from dataclasses import dataclass


@dataclass
class Client:
    weights: list[float]


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, x))))


def make_data(rng: random.Random, n: int) -> list[tuple[float, int]]:
    data = []
    for _ in range(n):
        x = rng.gauss(0, 1)
        y = 1 if x + rng.gauss(0, 0.55) > 0 else 0
        data.append((x, y))
    return data


def local_train(weights: list[float], data: list[tuple[float, int]], lr: float = 0.2) -> list[float]:
    w, b = weights
    for x, y in data:
        p = sigmoid(w * x + b)
        error = p - y
        w -= lr * error * x
        b -= lr * error
    return [w, b]


def accuracy(weights: list[float], data: list[tuple[float, int]]) -> float:
    correct = 0
    for x, y in data:
        pred = 1 if sigmoid(weights[0] * x + weights[1]) >= 0.5 else 0
        correct += pred == y
    return correct / len(data)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rounds", type=int, default=5)
    parser.add_argument("--clients", type=int, default=8)
    parser.add_argument("--samples", type=int, default=120)
    args = parser.parse_args()
    rng = random.Random(42)

    global_weights = [0.0, 0.0]
    test = make_data(rng, 500)
    clients = [make_data(rng, args.samples) for _ in range(args.clients)]

    for rnd in range(1, args.rounds + 1):
        updates = [local_train(global_weights[:], data) for data in clients]
        global_weights = [
            sum(update[i] for update in updates) / len(updates)
            for i in range(2)
        ]
        print(f"round={rnd} weights={global_weights} test_accuracy={accuracy(global_weights, test):.3f}")


if __name__ == "__main__":
    main()
