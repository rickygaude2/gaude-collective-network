# GAUD-E M1 Architecture

```text
                         GLOBAL COLLECTIVE AI
                                  |
                           model + datasets
                                  |
                    +-------------+-------------+
                    |                           |
               AI Worker A                AI Worker B ...
               CPU/GPU/edge              CPU/GPU/edge
                    |                           |
                    +-------------+-------------+
                                  |
                           signed receipt
                                  v
                         +----------------+
                         | Coordinator    |
                         | job scheduler  |
                         | SQLite         |
                         +-------+--------+
                                 |
                        verify contribution
                                 |
                                 v
                         +----------------+
                         | Chain Gateway  |
                         | Node + ethers  |
                         +-------+--------+
                                 |
                    +------------+-------------+
                    |                          |
                    v                          v
          ContributionRegistry          RewardsVault
                    |                          |
                    +------------+-------------+
                                 |
                                 v
                              EVM chain
```

## Why this split?

- Workers do compute.
- Coordinator handles scheduling and off-chain validation logic.
- Chain Gateway handles private-key-based transaction submission.
- Smart contracts store compact commitments and reward settlement.

The next major milestone is replacing the deterministic worker benchmark with real federated training and adding independent validators.
