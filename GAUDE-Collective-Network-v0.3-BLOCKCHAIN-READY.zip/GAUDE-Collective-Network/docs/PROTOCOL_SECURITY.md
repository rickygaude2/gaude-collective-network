# Protocol security priorities

The current M1 implementation is intentionally incomplete. Before a public network, the following must be added or reviewed:

1. authenticated worker registration;
2. independent validators rather than coordinator trust;
3. challenge/dispute mechanism;
4. replay protection across worker receipts and epochs;
5. rate limiting and anti-Sybil controls;
6. reward epoch caps and treasury controls;
7. multisig/timelock administration;
8. secure secret storage for protocol keys;
9. data poisoning and model poisoning defenses;
10. privacy review for any user-contributed data;
11. formal audit of smart contracts;
12. monitoring and incident response.
