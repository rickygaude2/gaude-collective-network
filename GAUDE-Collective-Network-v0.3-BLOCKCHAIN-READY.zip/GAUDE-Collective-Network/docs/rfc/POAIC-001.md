# PoAIC-001 — Proof-of-AI-Contribution (Draft)

## Problem

A decentralized AI network needs a way to distinguish useful verified work from fake or low-value activity.

## Proposal

Represent each contribution using a signed receipt containing:

- job identifier
- model and dataset commitments
- worker identity
- execution metadata
- evaluation metrics
- verification result

A future score can combine:

```text
verified work
× quality
× task difficulty
× reliability
× network demand
```

## Important constraint

Raw compute time should not be the sole reward signal. The protocol should reward useful outcomes and resist hardware concentration.

## Open research questions

- How do we verify training without rerunning the entire computation?
- How do we prevent collusion between workers and validators?
- How do we price heterogeneous hardware fairly?
- How do we handle poisoned or low-quality datasets?
