# GAUD-E RFCs

RFCs are public proposals for changing the protocol.

## Suggested process

1. Open an issue describing the problem.
2. Create an RFC when the problem requires a protocol-level decision.
3. Define security, economic and implementation implications.
4. Run a reproducible experiment when possible.
5. Seek community review.
6. Merge only after maintainers document the decision.

## First RFC topics

- PoAIC-001: Proof-of-AI-Contribution scoring
- P2P-001: Worker discovery and job gossip
- FL-001: Secure aggregation for collective learning
- VER-001: Verification tiers (replay, sampling, TEE, ZK)
- ECO-001: Contribution rewards and treasury policy
