# GAUDE Token — Research Tokenomics

## Prototype only

`GAUDE` is an ERC-20 prototype used to test economic interfaces. It is **not** a public investment offering.

## Proposed long-term roles

- pay for AI compute and services;
- reward verified network work;
- stake against dishonest behavior;
- participate in governance;
- fund ecosystem grants.

## Placeholder supply model

The prototype hard cap is **10,000,000,000 GAUDE**.

A future allocation should be determined only after the protocol has real usage. A research starting point is:

| Pool | Share |
|---|---:|
| Verified network contribution | 40% |
| Community / public goods | 20% |
| Treasury | 15% |
| Core contributors | 10% |
| Ecosystem / partnerships | 10% |
| Launch / foundation | 5% |

These percentages are discussion material, not a final allocation.

## Economic rule

The network should not depend on token inflation as its only source of value. Long-term rewards should increasingly be funded by real demand for AI services and by measurable useful contribution.
