# GAUD-E M1 API

Base URL for local development: `http://127.0.0.1:8080`

## `GET /health`

Returns coordinator and optional chain gateway status.

## `POST /workers/register`

Registers a worker capability profile.

Example:

```json
{
  "name": "worker-01",
  "hostname": "machine-01",
  "platform": "Linux",
  "cpu_count": 16,
  "memory_gb": 64,
  "gpu_name": "RTX 4090",
  "gpu_vram_gb": 24,
  "wallet_address": "0x..."
}
```

## `GET /jobs/next`

Returns the next available job.

## `POST /jobs/{job_id}/complete`

Submits a signed contribution receipt. The coordinator verifies the signature, computes a prototype reward score and, if configured, asks the chain gateway to record the contribution and settle the test reward.

## Security note

The M1 coordinator is a research prototype. Authentication, authorization, rate limiting, proof verification and validator consensus are incomplete. Do not expose it directly to the public Internet without a security review.
