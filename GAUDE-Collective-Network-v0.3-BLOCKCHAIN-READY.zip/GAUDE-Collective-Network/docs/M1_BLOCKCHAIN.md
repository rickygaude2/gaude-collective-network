# M1: Blockchain-connected prototype

M1 connects the contribution protocol to an EVM chain while keeping heavy AI computation off-chain.

## Data flow

```text
AI Worker
   |
   | signed receipt (worker key)
   v
Coordinator (FastAPI + SQLite)
   |
   | verifies signer + quality + policy
   v
Chain Gateway (Node + ethers)
   |
   +--> ContributionRegistry.recordContribution()
   |
   +--> RewardsVault.settle()
   v
EVM RPC / local chain / testnet
```

### Two-key design

- **Worker key:** signs a local contribution receipt; never needs permission to write the protocol contracts.
- **Protocol key:** lives in the chain gateway and writes verified contributions / rewards.

The coordinator can call the gateway with `CHAIN_GATEWAY_TOKEN`. Keep this secret private.

## Local chain

1. Install Foundry.
2. Run `anvil`.
3. In the repository root:

```bash
./scripts/setup_foundry.sh
export DEPLOYER_PRIVATE_KEY=<anvil-test-key>
forge script contracts/script/Deploy.s.sol --rpc-url http://127.0.0.1:8545 --broadcast
```

4. Copy the three deployed contract addresses into `chain/.env`.
5. Set `CHAIN_PRIVATE_KEY` in `chain/.env` to the deployer/test key (M1 only).
6. Set the same random development secret in both `.env` and `chain/.env`:

```text
CHAIN_GATEWAY_TOKEN=<long-random-string>
```

7. Start the chain gateway:

```bash
cd chain
cp .env.example .env
npm install
npm run dev
```

8. Start the coordinator with:

```bash
export CHAIN_GATEWAY_URL=http://127.0.0.1:8090
export CHAIN_GATEWAY_TOKEN=<same-random-string>
uvicorn coordinator.app:app --reload --port 8080
```

9. Run a worker with a **development-only** EVM private key:

```bash
export WORKER_PRIVATE_KEY=<anvil-test-key>
python node/worker.py --coordinator http://127.0.0.1:8080 --name worker-01
```

## Role setup

The deployment script gives the deployer `RECORDER_ROLE` and `SETTLER_ROLE`. Before any public testnet:

- use dedicated operational wallets;
- grant roles to those wallets;
- remove unnecessary admin authority;
- prefer multisig/timelock governance for sensitive functions;
- fund the vault only with explicit test allocations.

## Important

- Contracts are prototypes and unaudited.
- Never use a production/private-value wallet here.
- M1 does not yet provide trustless proof that a neural-network training step occurred.
- Public deployment requires independent security and legal review.
