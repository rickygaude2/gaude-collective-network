# Getting Started

## Prerequisites

- Python 3.11+
- Git
- Optional: NVIDIA GPU for future workers
- Optional: Foundry for Solidity development

## Run the collective-learning demo

No GPU is required.

```bash
python node/collective_learning.py --rounds 5 --clients 8 --samples 120
```

## Run the coordinator

Install dependencies:

```bash
python -m pip install -r coordinator/requirements.txt -r node/requirements.txt
```

Start the API:

```bash
bash scripts/run_local.sh
```

Then, from the repository root, run a worker:

```bash
python node/worker.py --coordinator http://127.0.0.1:8080 --name worker-01
```

Run a second worker with a different name to simulate another participant.

## Test

```bash
python -m pytest -q
```

## Next implementation target

Replace the synthetic worker task with a real ML inference/training backend and attach a signed node identity. Do not deploy the prototype token with real funds.
