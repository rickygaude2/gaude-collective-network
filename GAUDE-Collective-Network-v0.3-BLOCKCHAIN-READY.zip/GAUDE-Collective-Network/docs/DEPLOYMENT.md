# GAUD-E deployment guide

## Local development

Run the coordinator without a blockchain first. This is the fastest way to validate the AI-work protocol.

## Local EVM

Use Anvil with a development-only private key. Deploy the contracts with Foundry, then start the Node chain gateway.

## Public testnet

Before using any public testnet:

1. create a dedicated deployment wallet;
2. fund it only with testnet native gas;
3. deploy the contracts;
4. transfer recorder/settler roles to dedicated operational keys or a multisig;
5. configure the coordinator and chain gateway with environment variables;
6. run security tests and a small canary job;
7. publish addresses and transaction hashes in a versioned deployment manifest.

Do not use a production wallet or mainnet funds in this prototype.
