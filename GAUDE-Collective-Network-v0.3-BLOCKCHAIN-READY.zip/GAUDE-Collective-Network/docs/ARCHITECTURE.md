# Architecture

## Layer 1 — Collective AI

A shared model or model family evolves through reproducible training/evaluation rounds.

Candidate techniques:

- asynchronous reinforcement learning;
- federated learning;
- parameter-efficient fine-tuning;
- mixture-of-experts;
- distillation.

No single technique is mandatory yet.

## Layer 2 — Compute network

Workers advertise capabilities such as CPU count, memory, accelerator type, VRAM, bandwidth and availability. A scheduler assigns jobs according to capability and reputation.

## Layer 3 — Verification

A contribution should produce a compact receipt containing:

```text
job_id
model_commitment
dataset_commitment
worker_id
execution metadata
metrics
result commitment
proof commitment
```

The verification ladder is intended to grow from cheap methods to strong proofs:

```text
replication → random sampling → challenge/dispute → TEE/ZK where economical
```

## Layer 4 — Blockchain

The chain is used for:

- identity / authorization;
- task commitments;
- proof commitments;
- reputation snapshots;
- reward settlement;
- staking;
- governance.

It should not execute large tensor computations.

## Layer 5 — Storage

Large model weights and datasets belong off-chain in distributed/object storage. Public immutable content may use content addressing; private information must remain encrypted and access-controlled.

## Collective-learning path

```text
local data
   ↓
local training
   ↓
model update / delta
   ↓
privacy layer
   ↓
aggregator / secure aggregation
   ↓
validator checks
   ↓
new global checkpoint
```

The M0 demo deliberately omits privacy and cryptographic security. Those are explicit future milestones, not hidden assumptions.
