# Current status

## What works now

- Local coordinator API
- Worker registration
- Synthetic job assignment
- Contribution receipt hashing
- Small educational collective-learning simulation
- Python unit tests
- Prototype Solidity token and reward vault interfaces
- GitHub CI scaffold

## What is NOT production-ready

- P2P networking
- Cryptographic proof of AI work
- Secure aggregation
- Differential privacy
- GPU scheduling at Internet scale
- Mainnet smart contracts
- Production token economics
- Public token sale
- Security audit

The repository is intentionally a research/MVP starting point. Claims about decentralization, energy savings, profitability or global-scale performance must be demonstrated experimentally.
