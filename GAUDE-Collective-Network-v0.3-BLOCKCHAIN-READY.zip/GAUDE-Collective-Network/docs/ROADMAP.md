# Roadmap

## M0 — Runnable protocol loop

- [x] worker registration
- [x] job assignment
- [x] contribution receipt
- [x] local verification scaffold
- [x] unit tests
- [x] Solidity token/reward prototype

## M1 — Real AI workload

- [ ] model registry
- [ ] real inference backend
- [ ] benchmark registry
- [ ] GPU detection
- [ ] worker signed identity
- [ ] peer discovery

## M2 — Collective training

- [ ] federated aggregation
- [ ] asynchronous RL experiment
- [ ] checkpoint manifests
- [ ] reproducible evaluation suite
- [ ] privacy threat model

## M3 — Proof-of-AI-Contribution

- [ ] challenge/replay validation
- [ ] validator reputation
- [ ] staking/slashing research
- [ ] TEE experiments
- [ ] ZKML feasibility benchmark

## M4 — Public testnet

- [ ] on-chain job commitments
- [ ] reward settlement
- [ ] explorer/dashboard
- [ ] public docs
- [ ] bug bounty

## M5 — Collective foundation model

- [ ] community-vetted base model
- [ ] licensed dataset program
- [ ] distributed training campaign
- [ ] model provenance registry
- [ ] community benchmark governance

## M6 — Production network

Only after technical and legal review:

- [ ] audited contracts
- [ ] sustainable service revenue
- [ ] production token economics
- [ ] decentralized governance
- [ ] geographically distributed infrastructure
