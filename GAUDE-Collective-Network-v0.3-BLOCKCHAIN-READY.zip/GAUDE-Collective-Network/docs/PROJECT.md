# GAUD-E Collective Network — Project Definition

## Vision

Build an open network where the world's participating computers can collectively train and operate a shared artificial intelligence, while the people and organizations that contribute useful resources receive transparent protocol rewards.

## What is collective ownership here?

The project separates four ideas:

1. **Technical ownership:** source code and core protocols are open source.
2. **Model stewardship:** model versions and provenance are publicly documented.
3. **Economic participation:** verified contributors can receive protocol rewards.
4. **Governance:** the community can eventually influence protocol rules.

Legal ownership, securities status and revenue-sharing rights are jurisdiction-specific and are deliberately not promised by this repository.

## Non-goals for the first release

- training a frontier-scale model;
- creating a proprietary closed API;
- launching a public token sale;
- putting large datasets on a public blockchain;
- claiming guaranteed lower carbon emissions;
- claiming guaranteed financial returns.

## North-star metric

The most important metric is not token price.

> **Verified AI value created per unit of network resource.**

This can later be measured through model quality gain, useful tasks completed, latency, cost and energy per useful result.
