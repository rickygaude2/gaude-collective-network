# From M1 to a real collective AI network

## M1 — contribution protocol

Current milestone:

- signed worker receipts
- coordinator scheduling
- EVM registry
- reward settlement
- persistent local state

## M2 — real collective learning

1. Replace the deterministic benchmark with a small open ML model.
2. Add a federated-learning round manager.
3. Let multiple independent nodes submit model deltas.
4. Aggregate updates with secure aggregation.
5. Add independent validators and sampled replay checks.
6. Store the global-model manifest by content hash.
7. Record the model update commitment on-chain.

## M3 — permissionless network

1. P2P node discovery.
2. Capability-aware scheduling.
3. Challenge/dispute protocol.
4. Reputation scoring.
5. Sybil resistance.
6. Energy/carbon accounting.

## M4 — collective model

1. MoE experts and routing.
2. distributed RL.
3. model governance.
4. public testnet.
5. production economics after real demand exists.
