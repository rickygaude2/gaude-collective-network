## What does this PR do?

Describe the change in 2–5 sentences.

## Why is it needed?

What problem does it solve?

## Validation

- [ ] `python -m pytest -q`
- [ ] Relevant demo or script tested
- [ ] Documentation updated
- [ ] No private keys, credentials or secrets included

## Security / protocol impact

Does this change affect worker trust, verification, token logic, privacy or consensus? If yes, explain.
