"""GAUD-E worker and collective-learning demos."""
