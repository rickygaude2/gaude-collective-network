#!/usr/bin/env python3
"""GAUD-E M0 worker.

The current job is synthetic on purpose. It exercises the protocol loop before
we introduce real distributed ML, P2P networking and cryptographic proofs.
"""
from __future__ import annotations

import argparse
import platform
import socket
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path

# Allow `python node/worker.py` from the repository root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import psutil
import requests

from protocol.hashing import sha256_json


@dataclass
class WorkerInfo:
    name: str
    hostname: str
    platform: str
    cpu_count: int
    memory_gb: float


def hardware(name: str) -> WorkerInfo:
    return WorkerInfo(
        name=name,
        hostname=socket.gethostname(),
        platform=platform.platform(),
        cpu_count=psutil.cpu_count(logical=True) or 1,
        memory_gb=round(psutil.virtual_memory().total / (1024**3), 2),
    )


def build_receipt(job: dict, info: WorkerInfo) -> dict:
    started = time.time()
    # Deterministic M0 workload placeholder.
    synthetic_score = 1.0
    finished = time.time()
    body = {
        "job_id": job["job_id"],
        "model_hash": job["model_hash"],
        "dataset_hash": job["dataset_hash"],
        "worker": asdict(info),
        "started_at": started,
        "completed_at": finished,
        "metrics": {"synthetic_score": synthetic_score},
    }
    return {**body, "receipt_hash": sha256_json(body)}


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a GAUD-E worker")
    parser.add_argument("--coordinator", default="http://127.0.0.1:8080")
    parser.add_argument("--name", default=socket.gethostname())
    args = parser.parse_args()

    info = hardware(args.name)
    session = requests.Session()
    session.post(f"{args.coordinator}/workers/register", json=asdict(info), timeout=10).raise_for_status()
    job_response = session.get(f"{args.coordinator}/jobs/next", timeout=10)
    job_response.raise_for_status()
    job = job_response.json()
    if job.get("status") == "empty":
        print("No jobs available.")
        return

    receipt = build_receipt(job, info)
    response = session.post(
        f"{args.coordinator}/jobs/{job['job_id']}/complete",
        json=receipt,
        timeout=10,
    )
    response.raise_for_status()
    print(response.json())


if __name__ == "__main__":
    main()
