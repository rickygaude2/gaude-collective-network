# Smart contracts

These contracts are research/testnet primitives.

## Dependencies

Using Foundry:

```bash
forge install OpenZeppelin/openzeppelin-contracts --no-commit
forge build
forge test
```

Do not deploy with real funds. The current vault intentionally trusts an authorized settler; proof verification, replay protection and production controls are future work.
