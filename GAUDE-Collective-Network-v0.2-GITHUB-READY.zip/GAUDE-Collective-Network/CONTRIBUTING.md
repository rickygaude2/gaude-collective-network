# Contributing to GAUD-E Collective Network

Thank you for helping build an open collective AI infrastructure.

## Good first contributions

You do not need to be a blockchain expert. Useful contributions include:

- run the local MVP and report issues;
- improve documentation;
- benchmark the worker on different hardware;
- add a real inference backend;
- improve the collective-learning demo;
- implement peer discovery;
- design contribution verification tests;
- review smart-contract security;
- build dashboards and visualizations.

## Development principles

1. **Reproducibility first.** Every experiment should explain exactly how to repeat it.
2. **Privacy by design.** Do not upload raw personal data to public infrastructure.
3. **Verification before rewards.** Do not reward unverified compute as if it were useful work.
4. **Open interfaces.** Prefer documented protocols over vendor lock-in.
5. **Small pull requests.** One clear improvement per PR is easier to review.
6. **No financial promises.** GAUDE is a protocol prototype; contributors must not market it as guaranteed profit.

## Pull request checklist

- [ ] Tests added or updated.
- [ ] README/docs updated when behavior changes.
- [ ] No secrets, API keys or private datasets committed.
- [ ] Security implications considered.
- [ ] Reproduction steps included when fixing a bug.

## Community roadmap

The maintainers welcome competing implementations of worker nodes, validators, proof systems, distributed training backends and governance tooling.
