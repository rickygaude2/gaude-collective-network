# GAUD-E Website

Static landing page and contributor portal for GAUD-E Collective Network.

## Local preview

From the repository root, use any static web server. For example:

```bash
python -m http.server 4173 --directory website
```

Then open `http://127.0.0.1:4173`.

The site is intentionally dependency-free: HTML + CSS + JavaScript only.

## GitHub Pages

The repository includes `.github/workflows/deploy-pages.yml`, which deploys the `website/` directory when `main` changes.
