from __future__ import annotations

import hashlib
import time
import uuid
from typing import Any

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="GAUD-E Collective Coordinator", version="0.2.0")
workers: dict[str, dict[str, Any]] = {}
completions: dict[str, dict[str, Any]] = {}
job = {
    "job_id": f"job-{uuid.uuid4().hex[:12]}",
    "model_hash": hashlib.sha256(b"gaude-collective-model-m0").hexdigest(),
    "dataset_hash": hashlib.sha256(b"gaude-collective-dataset-m0").hexdigest(),
    "reward_units": 100,
}


class WorkerRegistration(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    hostname: str = Field(min_length=1, max_length=200)
    platform: str = Field(min_length=1, max_length=300)
    cpu_count: int = Field(ge=1, le=4096)
    memory_gb: float = Field(gt=0, le=100000)


@app.get("/")
def root() -> dict[str, Any]:
    return {"project": "GAUD-E Collective Network", "status": "m0-local", "workers": len(workers)}


@app.post("/workers/register")
def register_worker(payload: WorkerRegistration) -> dict[str, str]:
    workers[payload.name] = {**payload.model_dump(), "registered_at": time.time()}
    return {"status": "registered", "worker": payload.name}


@app.get("/workers")
def list_workers() -> dict[str, Any]:
    return {"workers": list(workers.values())}


@app.get("/jobs/next")
def next_job() -> dict[str, Any]:
    if completions.get(job["job_id"]):
        return {"status": "empty"}
    return job


@app.post("/jobs/{job_id}/complete")
def complete_job(job_id: str, receipt: dict[str, Any]) -> dict[str, Any]:
    if job_id != job["job_id"]:
        raise HTTPException(status_code=404, detail="unknown job")
    if receipt.get("receipt_hash") is None:
        raise HTTPException(status_code=400, detail="missing receipt_hash")
    completions[job_id] = receipt
    return {
        "status": "accepted-for-verification",
        "job_id": job_id,
        "receipt_hash": receipt["receipt_hash"],
        "simulated_reward_units": job["reward_units"],
    }


@app.get("/jobs/{job_id}")
def get_job(job_id: str) -> dict[str, Any]:
    if job_id != job["job_id"]:
        raise HTTPException(status_code=404, detail="unknown job")
    return {"job": job, "completion": completions.get(job_id)}
